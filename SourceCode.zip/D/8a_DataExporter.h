#pragma once // ??m b?o file header n�y ch? ???c bao g?m (include) m?t l?n trong qu� tr�nh bi�n d?ch
#include <iostream>  // Th? vi?n nh?p xu?t c? b?n
#include <fstream>   // Th? vi?n l�m vi?c v?i file (??c/ghi file)
#include <string>    // Th? vi?n x? l� chu?i k� t?
#include <vector>    // Th? vi?n s? d?ng m?ng ??ng (vector)

using namespace std;

class DataExporter {
public:
    /**
     * H�m x? l� xu?t d? li?u ra file
     * @param loaiDuLieu: Lo?i d? li?u mu?n xu?t (v� d?: "Nhat ky", "Ghi chu")
     * @param dinhDang: ??nh d?ng file ?�ch ("TXT" ho?c "CSV")
     * @param thuMucLuu: ???ng d?n th? m?c ?? l?u file sau khi xu?t
     * @return: true n?u xu?t th�nh c�ng, false n?u c� l?i x?y ra
     */
    bool exportFile(string loaiDuLieu, string dinhDang, string thuMucLuu) {

        // --- B??C 1: X�C ??NH FILE NGU?N ---
        // D?a v�o lo?i d? li?u ng??i d�ng y�u c?u ?? t�m file .csv t??ng ?ng trong h? th?ng
        string sourceFileName = "";

        if (loaiDuLieu == "Nhat ky" || loaiDuLieu == "Nhatky") {
            sourceFileName = "nhatky.csv";
        }
        else if (loaiDuLieu == "Ghi chu" || loaiDuLieu == "Ghichu") {
            sourceFileName = "soghichu.csv";
        }
        else {
            // N?u lo?i d? li?u kh�ng n?m trong danh s�ch h? tr? -> Tho�t v� tr? v? th?t b?i
            return false;
        }

        // --- B??C 2: KI?M TRA ??NH D?NG ??U RA ---
        // Ch? ch?p nh?n hai lo?i ??nh d?ng l� TXT ho?c CSV (kh�ng ph�n bi?t hoa th??ng)
        if (dinhDang != "TXT" && dinhDang != "CSV" && dinhDang != "txt" && dinhDang != "csv") {
            return false;
        }

        // --- B??C 3: M? FILE NGU?N ?? ??C ---
        ifstream sourceFile(sourceFileName); // M? lu?ng ??c file
        if (!sourceFile.is_open()) {
            return false; // N?u kh�ng m? ???c (file kh�ng t?n t?i), tr? v? false
        }

        // --- B??C 4: T?O FILE ?�CH (FILE XU?T) ---
        // X�c ??nh ?u�i file d?a tr�n ??nh d?ng ng??i d�ng ch?n
        string extension = (dinhDang == "TXT" || dinhDang == "txt") ? ".txt" : ".csv";

        // T?o ???ng d?n ??y ??: Th? m?c l?u + d?u g?ch ch�o + t�n file xu?t + ?u�i file
        string destFileName = thuMucLuu + "\\" + "Export_" + loaiDuLieu + extension;

        ofstream destFile(destFileName); // M? lu?ng ghi file
        if (!destFile.is_open()) {
            sourceFile.close(); // ?�ng file ngu?n ?� m? tr??c ?�
            return false; // Tr? v? false n?u ???ng d?n sai ho?c kh�ng c� quy?n ghi file
        }

        // --- B??C 5: SAO CH�P V� CHUY?N ??I D? LI?U ---
        string line;
        // ??c t?ng d�ng t? file ngu?n cho ??n h?t file
        while (getline(sourceFile, line)) {

            // N?u xu?t ra ??nh d?ng TXT:
            // Thay th? t?t c? d?u ph?y (,) t? file CSV g?c th�nh d?u Tab (\t) ?? tr�nh b�y ??p h?n
            if (dinhDang == "TXT" || dinhDang == "txt") {
                for (char& c : line) {
                    if (c == ',') c = '\t';
                }
            }

            // Ghi d�ng d? li?u (?� x? l� ho?c gi? nguy�n) v�o file ?�ch
            destFile << line << "\n";
        }

        // --- B??C 6: D?N D?P ---
        sourceFile.close(); // ?�ng k?t n?i file ngu?n
        destFile.close();   // ?�ng k?t n?i file ?�ch
        return true;        // Ho�n th�nh qu� tr�nh xu?t d? li?u
    }
};
