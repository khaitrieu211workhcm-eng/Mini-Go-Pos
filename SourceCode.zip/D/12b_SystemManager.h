﻿#pragma once
#include <iostream>

using namespace std;

// 1. Forward Declaration (Khai báo tiền thân):
// Thông báo cho trình biên dịch rằng "Controller" là một class sẽ xuất hiện sau.
// Điều này giúp tránh lỗi vòng lặp include khi SystemManager cần dùng Controller 
// và ngược lại.
class Controller;

class SystemManager {
private:
    bool isPowerOn = false; // Biến lưu trữ trạng thái nguồn (mặc định là Tắt)

public:
    // Hàm kiểm tra trạng thái nguồn hiện tại (Đang bật hay Đang tắt)
    bool getStatus() const { return isPowerOn; }

    /**
     * Khai báo hàm chuyển đổi trạng thái nguồn.
     * Lưu ý: Chỉ khai báo tên hàm ở đây, không viết nội dung (body) vì tại thời điểm này
     * trình biên dịch vẫn chưa biết cấu trúc chi tiết bên trong của Controller.
     */
    bool togglePower(Controller* appCtrl);
};

// 2. Nạp cấu trúc chi tiết của Controller:
// Sau khi đã định nghĩa xong lớp SystemManager, ta mới include Controller.
#include "10b_Controller.h"

/**
 * Hàm Toggle Power (Bật/Tắt nguồn):
 * Sử dụng từ khóa 'inline' để tối ưu hóa hiệu suất vì hàm này thường được gọi từ GUI.
 */
inline bool SystemManager::togglePower(Controller* appCtrl) {
    if (!isPowerOn) {
        // --- TRƯỜNG HỢP 1: HỆ THỐNG ĐANG TẮT -> BẬT LÊN ---
        isPowerOn = true;
        // Trả về true để GUI biết và chuyển sang giao diện chính/màn hình chờ
        return true;
    }
    else {
        // --- TRƯỜNG HỢP 2: HỆ THỐNG ĐANG BẬT -> TẮT ĐI ---

        // KIỂM TRA AN TOÀN DỮ LIỆU (Nghiệp vụ quan trọng):
        // Nếu Controller đang có một giao dịch dở dang (Bán hàng/Nhập/Xuất chưa bấm Lưu)
        if (appCtrl != nullptr && appCtrl->activeTransaction != nullptr) {

            // Nếu danh sách hàng hóa trong giao dịch tạm thời không rỗng
            if (!appCtrl->activeTransaction->isEmpty()) {
                // Tự động thực hiện lệnh lưu (Save) trước khi ngắt nguồn
                // Điều này đảm bảo nhân viên quên bấm Lưu thì dữ liệu vẫn vào file CSV
                appCtrl->processSaveTransaction();
            }
        }

        isPowerOn = false; // Chuyển trạng thái sang Tắt
        // Trả về false để GUI hiển thị thông báo "Đã lưu & Đang tắt..."
        return false;
    }
}
