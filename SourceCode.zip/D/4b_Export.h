﻿#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <ctime>
#include "1b_Transaction.h" // Kế thừa lớp cơ sở Transaction để dùng chung cấu trúc

using namespace std;

/**
 * Lớp Export: Xử lý nghiệp vụ xuất kho hàng hóa
 */
class Export : public Transaction {
private:
    string lyDo;     // Lý do xuất (Mượn hàng, Tiêu hủy, Thiên nguyện...)
    string ngayXuat; // Ngày thực hiện xuất kho (do người dùng nhập từ GUI)

public:
    // Cập nhật thông tin chi tiết về đơn xuất từ giao diện người dùng
    void setExportDetails(string lyDo, string ngayXuat) {
        this->lyDo = lyDo;
        this->ngayXuat = ngayXuat;
    }

    // --- 1. KIỂM TRA TÍNH HỢP LỆ CỦA MẶT HÀNG (Validate) ---
    bool validateItem(const Item& in) override {
        // Kiểm tra SKU và tên không được để trống
        if (in.sku.empty() || in.ten.empty()) return false;

        // Số lượng xuất phải lớn hơn 0
        if (in.sl <= 0) return false;

        // Phải có kết nối với DataManager (db) để kiểm tra dữ liệu hệ thống
        if (db == nullptr) return false;

        // Kiểm tra mã SKU này có tồn tại trong danh sách sản phẩm không
        if (!db->isValidSKU(in.sku)) return false;

        // QUAN TRỌNG: Kiểm tra số lượng xuất không được vượt quá số lượng tồn kho hiện tại
        if (in.sl > db->getTonKho(in.sku)) return false;

        return true;
    }

    // --- 2. THÊM MẶT HÀNG VÀO DANH SÁCH TẠM ---
    void addItem(const Item& in) override {
        // Nếu mặt hàng không hợp lệ (sai SKU hoặc thiếu hàng) thì không thêm
        if (!validateItem(in)) {
            return;
        }

        bool found = false;
        // Kiểm tra xem SKU này đã có trong danh sách chuẩn bị xuất chưa (xử lý trùng lặp)
        for (auto& item : list) {
            if (item.sku == in.sku) {
                // Nếu đã có: Cộng dồn số lượng và cập nhật tổng tiền mặt hàng đó
                item.sl += in.sl;
                item.tong = item.sl * item.gia;
                found = true;
                break;
            }
        }

        // Nếu là mặt hàng mới trong đơn xuất này
        if (!found) {
            // Lấy thêm thông tin bổ sung (Khấu trừ, HSD) từ Database hệ thống
            Product p = db->getProductInfo(in.sku);

            Item newItem = in;
            newItem.khauTru = p.khauTru;
            newItem.hsd = p.hsd;
            newItem.tong = in.sl * in.gia;

            list.push_back(newItem); // Thêm vào mảng tạm
        }
    }

    // --- 3. KIỂM TRA ĐIỀU KIỆN TRƯỚC KHI LƯU FILE ---
    bool validateBeforeSave() override {
        // Kiểm tra danh sách xuất không rỗng và ngày xuất đã được điền
        if (list.empty() || this->ngayXuat.empty()) {
            return false;
        }
        return true;
    }

    // --- 4. LƯU CHI TIẾT PHIẾU XUẤT RA FILE CSV ---
    void save() override {
        if (!validateBeforeSave()) return;

        // Tạo mã định danh duy nhất cho phiếu xuất dựa trên thời gian (timestamp)
        time_t now = ::time(0);
        this->time = to_string(now);
        this->id = "XK_" + this->time; // Ví dụ: XK_1714812345

        // Tạo file CSV riêng cho mỗi lần xuất kho
        string fileName = "xuatkho_" + this->time + ".csv";
        ofstream fCsv(fileName);

        if (fCsv.is_open()) {
            // Ghi dòng tiêu đề phiếu xuất
            fCsv << "Ma XK: " << this->id << ", Ngay Xuat: " << this->ngayXuat << ", Ly Do: " << this->lyDo << "\n";
            fCsv << "STT,SKU,Ten SP,SL,Gia Tri,KT,HSD,Tong\n";

            int stt = 1;
            for (const auto& item : list) {
                // Ghi từng mặt hàng
                fCsv << stt++ << "," << item.sku << "," << item.ten << ","
                    << item.sl << "," << item.gia << "," << item.khauTru << ","
                    << item.hsd << "," << item.tong << "\n";

                // --- NGHIỆP VỤ QUAN TRỌNG ---
                // Cập nhật lại kho tổng: Trừ đi số lượng vừa xuất (dùng dấu âm -item.sl)
                if (db != nullptr) {
                    db->updateStock(item.sku, -item.sl);
                }
            }
            // Ghi tổng giá trị của toàn bộ phiếu xuất
            fCsv << "Tong Tien,,,,,,," << getTotalAmount() << "\n";
            fCsv.close();
        }
    }

    // --- 5. GHI NHẬT KÝ HOẠT ĐỘNG ---
    void writeLog() override {
        // Ghi lại dấu vết hoạt động vào file nhật ký dùng chung của hệ thống
        ofstream fLog("nhatky.csv", ios::app); // Mở ở chế độ append (ghi tiếp vào cuối file)
        if (fLog.is_open()) {
            // Định dạng: [Thời gian, Loại hành động, Mã phiếu xuất]
            fLog << this->time << ",XUAT_KHO," << this->id << "\n";
            fLog.close();
        }
    }
};
