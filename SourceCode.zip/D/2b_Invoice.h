﻿#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include <ctime>
#include "1b_Transaction.h" // Kế thừa lớp cơ sở Transaction

using namespace std;

/**
 * Lớp Invoice: Quản lý nghiệp vụ bán hàng và xuất hóa đơn
 */
class Invoice : public Transaction {
public:
    // --- 1. KIỂM TRA TÍNH HỢP LỆ (Validate) ---
    // Đảm bảo hàng bán ra phải có trong danh mục và đủ số lượng tồn kho
    bool validateItem(const Item& in) override {
        if (db == nullptr) return false;

        // Kiểm tra SKU có tồn tại trong hệ thống (file danh mục hàng) hay không
        if (!db->isValidSKU(in.sku)) return false;

        // Kiểm tra số lượng nhập vào phải lớn hơn 0 
        // và không được vượt quá số lượng tồn kho thực tế của mã hàng đó
        if (in.sl <= 0 || in.sl > db->getTonKho(in.sku)) return false;

        return true;
    }

    // --- 2. THÊM MẶT HÀNG VÀO GIỎ HÀNG TẠM ---
    void addItem(const Item& in) override {
        // Bước 1: Validate trước, nếu sai (ví dụ: quá tồn kho) thì thoát ngay
        if (!validateItem(in)) {
            return;
        }

        // Bước 2: Tự động lấy thông tin chi tiết (Tên, Giá, Khấu trừ) từ Database
        Product p = db->getProductInfo(in.sku);

        bool found = false;
        // Bước 3: Kiểm tra sản phẩm đã có trong giỏ hàng hiện tại chưa
        for (auto& item : list) {
            if (item.sku == in.sku) {
                // Nếu đã có: Cộng dồn số lượng
                item.sl += in.sl;
                // Tính lại thành tiền: (Số lượng * Giá) - Khấu trừ
                item.tong = (item.sl * p.gia) - p.khauTru;
                found = true;
                break;
            }
        }

        // Bước 4: Nếu là sản phẩm mới thêm lần đầu vào hóa đơn
        if (!found) {
            Item newItem;
            newItem.sku = in.sku;
            newItem.ten = p.ten;
            newItem.sl = in.sl;
            newItem.gia = p.gia;
            newItem.khauTru = p.khauTru;
            newItem.hsd = p.hsd;
            newItem.tong = (in.sl * p.gia) - p.khauTru;

            list.push_back(newItem);
        }
    }

    // --- 3. LƯU VÀ XUẤT HÓA ĐƠN ---
    void save() override {
        // Kiểm tra xem giỏ hàng có trống không trước khi lưu
        if (!validateBeforeSave()) return;

        // 1. Tạo mã hóa đơn dựa trên thời gian thực (Unix Timestamp)
        time_t now = ::time(0); // Sử dụng :: để gọi hàm toàn cục của C
        this->time = to_string(now);
        this->id = "HD_" + this->time;

        // 2. Định dạng tên file cho 2 loại báo cáo (CSV để quản lý, TXT để in bill)
        string csvFileName = "hoadon_" + this->time + ".csv";
        string txtFileName = "hoadon_" + this->time + ".txt";

        // --- GHI FILE CSV (Dùng để nhập liệu/Excel) ---
        ofstream fCsv(csvFileName);
        if (fCsv.is_open()) {
            fCsv << "STT,SKU,Ten Hang,SL,Gia,Khau Tru,HSD,Thanh Tien\n";
            int stt = 1;
            for (const auto& item : list) {
                fCsv << stt++ << "," << item.sku << "," << item.ten << ","
                    << item.sl << "," << item.gia << "," << item.khauTru << ","
                    << item.hsd << "," << item.tong << "\n";

                // NGHIỆP VỤ QUAN TRỌNG: Trừ số lượng tồn kho trong hệ thống
                db->updateStock(item.sku, -item.sl);
            }
            fCsv << "Tong Tien,,,,,,," << getTotalAmount() << "\n";
            fCsv.close();
        }

        // --- GHI FILE TXT (Dạng hóa đơn in ấn cho khách hàng) ---
        ofstream fTxt(txtFileName);
        if (fTxt.is_open()) {
            fTxt << "=== HOA DON BAN HANG ===\n";
            fTxt << "Ma Hoa Don: " << this->id << "\n";
            fTxt << "Thoi gian: " << this->time << "\n";
            fTxt << "------------------------\n";
            int stt = 1;
            for (const auto& item : list) {
                fTxt << stt++ << ". " << item.ten << " (SKU: " << item.sku << ")\n";
                fTxt << "   SL: " << item.sl << " x Gia: " << item.gia << " = " << item.tong << "\n";
            }
            fTxt << "------------------------\n";
            fTxt << "TONG CONG: " << getTotalAmount() << " VND\n";
            fTxt.close();
        }
    }

    // --- 4. GHI NHẬT KÝ HOẠT ĐỘNG (Logging) ---
    void writeLog() override {
        // Lưu lại lịch sử bán hàng vào nhật ký chung của hệ thống
        ofstream fLog("nhatky.csv", ios::app); // Chế độ ios::app để ghi nối tiếp vào cuối file
        if (fLog.is_open()) {
            // Định dạng: [Thời gian, Hành động, Mã hóa đơn, Tổng tiền]
            fLog << this->time << ",BAN_HANG," << this->id << "," << getTotalAmount() << "\n";
            fLog.close();
        }
    }
};
