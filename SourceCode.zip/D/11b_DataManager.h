﻿#pragma once
#include <iostream>
#include <vector>
#include <string>

using namespace std;

// ==============================================================================
// 1. ĐỊNH NGHĨA CẤU TRÚC DỮ LIỆU (STRUCTS)
// ==============================================================================
struct User {
    string ma;
    string role;
};

struct Product {
    string sku;
    string ten;
    double gia = 0.0;
    double khauTru = 0.0;
    int tonKho = 0;
    string hsd;
};

// ==============================================================================
// 2. LỚP QUẢN LÝ DỮ LIỆU TỪ FILE CSV/TXT (RAM CỦA HỆ THỐNG)
// ==============================================================================
class DataManager {
private:
    vector<Product> productList;
    vector<User> userList;

    // [CODE MỚI THÊM]: Biến lưu trữ tổng doanh thu bán hàng trong ca
    double tongDoanhThu = 0.0;

public:
    // =========================================================
    // KHU VỰC 1: XỬ LÝ DỮ LIỆU HÀNG HÓA
    // =========================================================
    void addProduct(const Product& p) {
        productList.push_back(p);
    }

    bool isValidSKU(string sku) {
        for (const auto& p : productList) {
            if (p.sku == sku) return true;
        }
        return false;
    }

    int getTonKho(string sku) {
        for (const auto& p : productList) {
            if (p.sku == sku) return p.tonKho;
        }
        return 0;
    }

    Product getProductInfo(string sku) {
        for (const auto& p : productList) {
            if (p.sku == sku) return p;
        }
        return Product();
    }

    void updateStock(string sku, int qtyChange) {
        for (auto& p : productList) {
            if (p.sku == sku) {
                p.tonKho += qtyChange;
                return;
            }
        }
    }

    // =========================================================
    // KHU VỰC 2: XỬ LÝ DỮ LIỆU NHÂN SỰ
    // =========================================================
    void addUser(const User& u) {
        userList.push_back(u);
    }

    // ĐÃ FIX LỖI C2535: Chỉ giữ lại duy nhất 1 hàm kiểm tra này
    bool isValidUser(string ma) {
        for (const auto& u : userList) {
            if (u.ma == ma) return true;
        }
        return false;
    }

    // =========================================================
    // KHU VỰC 3: QUẢN LÝ DOANH THU (CẬP NHẬT CHO GIAO DIỆN)
    // =========================================================
    // Hàm dùng để Controller gọi khi lưu hóa đơn thành công
    void addDoanhThu(double tien) {
        tongDoanhThu += tien;
    }

    // Hàm dùng để View (GUI) lấy số tiền hiển thị lên nhãn
    double getDoanhThu() {
        return tongDoanhThu;
    }
};