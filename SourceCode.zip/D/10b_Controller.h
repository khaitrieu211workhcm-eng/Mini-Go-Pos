﻿#pragma once
#include <iostream>
#include <vector>
#include <string>

// Nhúng tất cả các Header cần thiết để Controller có thể quản lý
#include "11b_DataManager.h"   // Kho dữ liệu
#include "0b_UploadManager.h" // Xử lý file đầu vào
#include "1b_Transaction.h"   // Lớp cha của các giao dịch
#include "2b_Invoice.h"       // Lớp Bán hàng
#include "3b_Import.h"        // Lớp Nhập kho
#include "4b_Export.h"        // Lớp Xuất kho
#include "6b_NoteManager.h"   // Lớp Ghi chú
#include "7b_ShiftManager.h"  // Lớp Quản lý ca
#include "8a_DataExporter.h"  // Lớp Xuất báo cáo

using namespace std;

/**
 * Lớp Controller: Trung tâm điều phối của ứng dụng
 */
class Controller {
public:
    // 1. KHO DỮ LIỆU TRUNG TÂM (Lưu trên RAM)
    // Mọi module khác đều dùng chung con trỏ từ đối tượng db này
    DataManager db;

    // 2. CÁC MODULE NGHIỆP VỤ (Khởi tạo tĩnh)
    Invoice invoiceObj;       // Xử lý Bán hàng 
    Import importObj;         // Xử lý Nhập kho 
    Export exportObj;         // Xử lý Xuất kho 
    NoteManager note;         // Xử lý Ghi chú 
    ShiftManager shift;       // Xử lý Mở/Kết ca 
    DataExporter exporter;    // Chức năng xuất báo cáo 
    UploadManager uploadObj;  // Xử lý đọc file danh mục hàng hóa/nhân viên 

    // 3. CON TRỎ ĐA HÌNH (Polymorphism)
    // Đây là "Cánh tay robot" linh hoạt: Lúc thì trỏ vào Bán hàng, lúc trỏ vào Nhập kho
    // Giúp GUI không phải viết quá nhiều hàm saveBanHang(), saveNhapKho()...
    Transaction* activeTransaction = nullptr;

    /**
     * 4. CONSTRUCTOR (Hàm khởi tạo)
     * Thực hiện "Cắm dây" (Dependency Injection): Truyền địa chỉ của 'db'
     * vào các module để tất cả dùng chung một nguồn dữ liệu duy nhất.
     */
    Controller() {
        uploadObj.setDataManager(&db);
        invoiceObj.setDataManager(&db);
        importObj.setDataManager(&db);
        exportObj.setDataManager(&db);
        shift.setDataManager(&db);
        note.setDataManager(&db);

        // Tạo sẵn một User Admin để có thể đăng nhập/kiểm tra hệ thống ngay lập tức
        User testUser;
        testUser.ma = "ADMIN";
        testUser.role = "QuanLy";
        db.addUser(testUser);
    }

    /**
     * 5. HÀM CHUYỂN TAB
     * Khi người dùng bấm nút trên GUI, hàm này sẽ điều hướng con trỏ activeTransaction
     */
    void switchTab(int tabID) {
        switch (tabID) {
        case 54: // ID nút BÁN HÀNG
            activeTransaction = &invoiceObj;
            break;
        case 55: // ID nút NHẬP KHO
            activeTransaction = &importObj;
            break;
        case 56: // ID nút XUẤT KHO
            activeTransaction = &exportObj;
            break;
        default:
            // Các tab như Ghi chú, Mở ca không kế thừa Transaction thì set Null
            activeTransaction = nullptr;
            break;
        }
    }

    /**
     * 6. HÀM XỬ LÝ LƯU ĐA HÌNH (Cực kỳ quan trọng)
     * GUI chỉ cần gọi hàm này khi người dùng bấm nút "LƯU" hoặc "THANH TOÁN"
     */
    bool processSaveTransaction() {
        // Kiểm tra xem có đang ở Tab giao dịch (Bán/Nhập/Xuất) không
        if (activeTransaction == nullptr) return false;

        // BƯỚC 1: Kiểm tra danh sách hàng hóa có trống không (Validate)
        if (!activeTransaction->validateBeforeSave()) {
            return false; // Trả về false để GUI báo lỗi "Danh sách trống"
        }

        // BƯỚC 2: Gọi các hàm thực thi (Đã được định nghĩa đa hình ở các lớp con)
        activeTransaction->save();       // Lưu file chi tiết phiếu (CSV/TXT)
        activeTransaction->writeLog();   // Ghi lại lịch sử vào nhatky.csv
        activeTransaction->reset();      // Dọn dẹp bộ nhớ tạm để chuẩn bị cho đơn hàng tiếp theo

        return true; // Thành công -> GUI xóa trắng bảng hiển thị và báo thành công
    }
};
