﻿#pragma once // Ngăn chặn việc khai báo chồng chéo thư viện khi include nhiều nơi
#include <iostream>
#include <vector>
#include <string>
#include <fstream>  // Thư viện để làm việc với file (ghi nhật ký)
#include <ctime>    // Thư viện xử lý thời gian hệ thống
#include <windows.h> // Hỗ trợ các hàm hệ thống Windows

// Nhúng lớp quản lý dữ liệu để sử dụng các hàm kiểm tra mã nhân viên/quản lý
#include "11b_DataManager.h"

using namespace std;

class ShiftManager {
private:
    // Con trỏ db kết nối tới đối tượng DataManager để truy vấn dữ liệu từ file CSV
    DataManager* db = nullptr;

    /*
     * Hàm nội bộ: Lấy thời gian hiện tại của hệ thống
     * Trả về chuỗi định dạng: YYYY-MM-DD HH:MM:SS
     */
    string getCurrentTimeStr() {
        time_t now = time(0); // Lấy thời gian hiện tại dưới dạng số giây
        tm ltm;

        // Sử dụng localtime_s (an toàn hơn localtime) để chuyển đổi sang cấu trúc thời gian
        localtime_s(&ltm, &now);

        // Tạo bộ đệm lưu trữ chuỗi thời gian
        string buffer;
        buffer.resize(80);

        // Định dạng thời gian thành chuỗi (Năm-Tháng-Ngày Giờ:Phút:Giây)
        strftime(&buffer.front(), buffer.size(), "%Y-%m-%d %H:%M:%S", &ltm);
        return string(buffer.c_str());
    }

public:
    // Phương thức để gán (tiêm) đối tượng DataManager vào lớp này
    void setDataManager(DataManager* manager) {
        this->db = manager;
    }

    /*
     * Hàm lưu dữ liệu MỞ CA
     * maQL: Mã quản lý, maNV: Mã nhân viên, tienDauStr: Tiền đầu ca, tienKetStr: Tiền trong két
     */
    bool saveMoCa(string maQL, string maNV, string tienDauStr, string tienKetStr) {
        // 1. Kiểm tra đầu vào: Không được để trống
        if (maQL.empty() || maNV.empty() || tienDauStr.empty() || tienKetStr.empty()) return false;

        // Kiểm tra mã QL và mã NV có tồn tại trong cơ sở dữ liệu (file CSV) không
        if (db == nullptr || !db->isValidUser(maQL) || !db->isValidUser(maNV)) return false;

        // 2. Chuyển đổi kiểu dữ liệu từ chuỗi sang số thực (double)
        double tienDau = 0, tienKet = 0;
        try {
            tienDau = stod(tienDauStr);
            tienKet = stod(tienKetStr);
            // Tiền không được là số âm
            if (tienDau < 0 || tienKet < 0) return false;
        }
        catch (...) {
            return false; // Trả về false nếu chuỗi tiền chứa ký tự không phải số
        }

        // 3. Ghi dữ liệu vào file nhatky.csv (chế độ ios::app - ghi tiếp vào cuối file)
        ofstream file("nhatky.csv", ios::app);
        if (file.is_open()) {
            file << getCurrentTimeStr() << ",MO_CA,QL:" << maQL << ",NV:" << maNV
                << ",DauCa:" << tienDau << ",Ket:" << tienKet << "\n";
            file.close();
            return true;
        }
        return false;
    }

    /*
     * Hàm lưu dữ liệu KẾT CA
     * Thêm các thông số về doanh thu và chênh lệch tiền thực tế
     */
    bool saveKetCa(string maQL, string maNV, string tienKetStr, string doanhThuStr, string chenhLechStr, string ghiChu) {
        // 1. Kiểm tra rỗng cho các trường bắt buộc
        if (maQL.empty() || maNV.empty() || tienKetStr.empty() || doanhThuStr.empty() || chenhLechStr.empty()) return false;

        // 2. Kiểm tra tính hợp lệ của người dùng qua DataManager
        if (db == nullptr || !db->isValidUser(maQL) || !db->isValidUser(maNV)) return false;

        // 3. Kiểm tra và chuyển đổi định dạng tiền tệ
        double tienKet = 0, doanhThu = 0, chenhLech = 0;
        try {
            tienKet = stod(tienKetStr);
            doanhThu = stod(doanhThuStr);
            chenhLech = stod(chenhLechStr);
        }
        catch (...) {
            return false;
        }

        // 4. Mọi thứ hợp lệ -> Ghi dòng nhật ký kết ca vào file CSV
        ofstream file("nhatky.csv", ios::app);
        if (file.is_open()) {
            file << getCurrentTimeStr() << ",KET_CA,QL:" << maQL << ",NV:" << maNV
                << ",Ket:" << tienKet << ",DT:" << doanhThu << ",ChenhLech:" << chenhLech
                << ",Note:" << ghiChu << "\n";
            file.close();
            return true;
        }
        return false;
    }
};
