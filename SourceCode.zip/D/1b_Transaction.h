﻿#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

// Nhúng DataManager để lớp này có thể truy cập các hàm kiểm tra kho hàng, nhân viên
#include "11b_DataManager.h" 

using namespace std;

/**
 * Cấu trúc Item: Đại diện cho một dòng hàng hóa trong giao dịch
 * Ví dụ: Một dòng trong hóa đơn gồm mã, tên, số lượng, giá...
 */
struct Item {
    string sku;         // Mã định danh sản phẩm (Stock Keeping Unit)
    string ten;         // Tên gọi sản phẩm
    int sl = 0;         // Số lượng (mặc định bằng 0 để tránh lỗi giá trị rác)
    double gia = 0.0;   // Đơn giá
    double khauTru = 0.0; // Số tiền được giảm trừ/chiết khấu
    string hsd;         // Hạn sử dụng (lưu dạng chuỗi YYYY-MM-DD)
    double tong = 0.0;  // Thành tiền của riêng dòng này (thường là sl * gia - khauTru)
};

/**
 * Lớp Transaction: Lớp cha định nghĩa các hành vi chung cho mọi loại phiếu
 * (Hóa đơn, Phiếu nhập, Phiếu xuất)
 */
class Transaction {
protected:
    // Mảng lưu trữ các mặt hàng đang được chọn (Lưu tạm trên RAM)
    // Dữ liệu này sẽ được hiển thị lên ListView trên giao diện
    vector<Item> list;

    string id;   // Mã số phiếu (Ví dụ: HD001, NK002)
    string time; // Dấu mốc thời gian thực hiện giao dịch (Timestamp)

    // Con trỏ kết nối đến DataManager để thực hiện các nghiệp vụ như:
    // Kiểm tra SKU tồn tại, lấy giá hàng, trừ tồn kho...
    DataManager* db = nullptr;

public:
    // Hàm hủy ảo (Virtual Destructor) để đảm bảo các lớp con được giải phóng bộ nhớ an toàn
    virtual ~Transaction() = default;

    // Thêm trực tiếp một Item vào danh sách tạm
    void addTempItem(const Item& itm) {
        list.push_back(itm);
    }

    // "Cắm dây" kết nối với DataManager
    void setDataManager(DataManager* manager) {
        this->db = manager;
    }

    // Kiểm tra xem danh sách hiện tại có trống không
    bool isEmpty() const { return list.empty(); }

    // Trả về danh sách các mặt hàng (dùng để GUI vẽ lên bảng)
    const vector<Item>& getList() const { return list; }

    /**
     * Tính tổng số tiền của toàn bộ giao dịch
     * Cộng dồn tất cả các giá trị 'tong' của từng Item trong vector
     */
    double getTotalAmount() const {
        double total = 0;
        for (const auto& item : list) {
            total += item.tong;
        }
        return total;
    }

    // --- CÁC HÀM THUẦN ẢO (PURE VIRTUAL FUNCTIONS) ---
    // Các lớp con (Invoice, Import, Export) BẮT BUỘC phải cài đặt cụ thể các hàm này

    // 1. Kiểm tra tính hợp lệ của sản phẩm (Ví dụ: Bán hàng thì phải kiểm tra tồn kho)
    virtual bool validateItem(const Item& in) = 0;

    // 2. Thêm sản phẩm vào list (Xử lý cộng dồn nếu trùng mã SKU)
    virtual void addItem(const Item& in) = 0;

    // 3. Xóa một dòng hàng hóa khỏi danh sách dựa trên vị trí (index)
    virtual void removeItem(int index) {
        if (index >= 0 && index < (int)list.size()) {
            list.erase(list.begin() + index);
        }
    }

    // 4. Kiểm tra tổng thể trước khi bấm nút Lưu
    virtual bool validateBeforeSave() {
        if (list.empty()) {
            cout << "Loi: Danh sach trong, khong the luu!" << endl;
            return false;
        }
        return true;
    }

    // 5. Ghi dữ liệu ra file vật lý (CSV/TXT)
    virtual void save() = 0;

    // 6. Ghi lại lịch sử hoạt động vào file nhật ký hệ thống
    virtual void writeLog() = 0;

    /**
     * 7. Làm sạch trạng thái: Xóa hết hàng trong list, reset mã và thời gian
     * Thường dùng sau khi đã lưu file thành công để chuẩn bị cho giao dịch mới.
     */
    void reset() {
        list.clear();
        id = "";
        time = "";
    }
};
