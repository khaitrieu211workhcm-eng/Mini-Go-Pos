﻿#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <ctime>
#include "1b_Transaction.h" // Kế thừa từ lớp cơ sở Transaction

using namespace std;

/**
 * Lớp Import: Quản lý nghiệp vụ nhập hàng hóa vào kho
 */
class Import : public Transaction {
private:
    string nhaCC;     // Lưu trữ thông tin Nhà cung cấp cho đơn nhập hiện tại
    string ngayNhap;  // Lưu trữ ngày nhập hàng

public:
    // Nhận thông tin chi tiết về đơn nhập từ giao diện (GUI)
    void setImportDetails(string nhaCungCap, string date) {
        this->nhaCC = nhaCungCap;
        this->ngayNhap = date;
    }

    // --- 1. KIỂM TRA TÍNH HỢP LỆ CỦA MẶT HÀNG ---
    bool validateItem(const Item& in) override {
        // [QUY TẮC]: Mã SKU, Tên sản phẩm và Hạn sử dụng không được để trống
        if (in.sku.empty() || in.ten.empty() || in.hsd.empty()) return false;

        // [QUY TẮC]: Số lượng nhập và Giá nhập phải lớn hơn 0
        if (in.sl <= 0 || in.gia <= 0) return false;

        return true;
    }

    // --- 2. THÊM MẶT HÀNG VÀO DANH SÁCH CHỜ ---
    void addItem(const Item& in) override {
        // Kiểm tra tính hợp lệ trước khi cho phép thêm vào danh sách
        if (!validateItem(in)) {
            return; // Nếu không hợp lệ, thoát ra để giao diện hiển thị thông báo lỗi
        }

        bool found = false;
        // Kiểm tra xem sản phẩm (SKU) này đã có trong danh sách nhập hiện tại chưa
        for (auto& item : list) {
            if (item.sku == in.sku) {
                // Nếu đã tồn tại: Cộng dồn số lượng và cập nhật thông tin mới nhất (Giá, HSD)
                item.sl += in.sl;
                item.gia = in.gia;
                item.hsd = in.hsd;
                item.tong = item.sl * item.gia; // Tính lại thành tiền
                found = true;
                break;
            }
        }

        // Nếu là SKU mới trong đơn nhập này
        if (!found) {
            Item newItem = in;
            newItem.khauTru = 0; // Hàng nhập kho mới luôn có khấu trừ bằng 0
            newItem.tong = in.sl * in.gia;
            list.push_back(newItem); // Thêm vào mảng tạm (vector)
        }
    }

    // --- 3. KIỂM TRA ĐIỀU KIỆN TRƯỚC KHI XUẤT FILE ---
    bool validateBeforeSave() override {
        // Danh sách hàng phải có ít nhất 1 món và phải có ngày nhập mới cho lưu
        if (list.empty() || this->ngayNhap.empty()) return false;
        return true;
    }

    // --- 4. LƯU CHI TIẾT ĐƠN NHẬP VÀ CẬP NHẬT KHO ---
    void save() override {
        if (!validateBeforeSave()) return;

        // 1. Tạo mã nhập kho (ID) duy nhất dựa trên thời gian thực
        // Sử dụng ::time(0) để chỉ định rõ hàm time của hệ thống C
        time_t now = ::time(0);
        this->time = to_string(now);
        this->id = "NK_" + this->time;

        // 2. Tạo và ghi file CSV chi tiết đơn nhập
        string fileName = "nhapkho_" + this->time + ".csv";
        ofstream fCsv(fileName);
        if (fCsv.is_open()) {
            // Ghi thông tin chung của đơn hàng
            fCsv << "Ma NK: " << this->id << ", Ngay Nhap: " << this->ngayNhap << ", Nha CC: " << this->nhaCC << "\n";
            fCsv << "STT,SKU,Ten SP,SL,Gia Nhap,HSD,Thanh Tien\n";

            int stt = 1;
            for (const auto& item : list) {
                // Ghi chi tiết từng sản phẩm
                fCsv << stt++ << "," << item.sku << "," << item.ten << ","
                    << item.sl << "," << item.gia << "," << item.hsd << ","
                    << item.tong << "\n";

                // --- NGHIỆP VỤ THỰC TẾ ---
                // Gọi sang DataManager để cộng thêm số lượng vào tổng tồn kho của hệ thống
                if (db != nullptr) {
                    db->updateStock(item.sku, item.sl);
                }
            }
            // Ghi tổng tiền của toàn bộ phiếu nhập
            fCsv << "Tong Tien,,,,,,," << getTotalAmount() << "\n";
            fCsv.close();
        }
    }

    // --- 5. GHI NHẬT KÝ HOẠT ĐỘNG ---
    void writeLog() override {
        // Ghi lại lịch sử nhập kho vào file nhatky.csv để theo dõi dòng thời gian
        ofstream fLog("nhatky.csv", ios::app); // Mở ở chế độ append (ghi tiếp vào cuối file)
        if (fLog.is_open()) {
            // Định dạng lưu: [Thời gian Unix, Hành động, Mã phiếu nhập]
            fLog << this->time << ",NHAP_KHO," << this->id << "\n";
            fLog.close();
        }
    }
};
