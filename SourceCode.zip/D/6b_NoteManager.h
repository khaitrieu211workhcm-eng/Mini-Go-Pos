﻿#pragma once // Đảm bảo file header chỉ được nạp một lần duy nhất khi biên dịch
#include <iostream>
#include <vector>
#include <string>
#include <fstream>  // Thư viện hỗ trợ ghi file (soghichu.csv, nhatky.csv)
#include <ctime>    // Thư viện hỗ trợ lấy thời gian hệ thống
#include "11b_DataManager.h" // Nhúng lớp quản lý dữ liệu để kiểm tra User hợp lệ

using namespace std;

/**
 * Cấu trúc (Struct) lưu trữ một dòng ghi chú
 * Được thiết kế để tương thích với việc hiển thị dữ liệu lên ListView của GUI
 */
struct NoteItem {
    string caLam;    // Tên ca làm việc
    string nguoiLap; // Tên/Mã người lập ghi chú
    string noiDung;  // Nội dung chi tiết của ghi chú
    string phanLoai; // Loại ghi chú (Y tế, Cháy nổ, Thuế...)
    string thoiGian; // Thời gian lập ghi chú
    string quanTrong; // Mức độ ưu tiên hoặc mã liên quan
};

class NoteManager {
private:
    DataManager* db = nullptr; // Con trỏ kết nối đến lớp quản lý dữ liệu gốc
    vector<NoteItem> list;    // Danh sách các ghi chú đã thêm (dùng để hiển thị real-time)

public:
    // Kết nối đối tượng DataManager vào lớp NoteManager (Dependency Injection)
    void setDataManager(DataManager* manager) {
        this->db = manager;
    }

    // Trả về danh sách ghi chú (dạng tham chiếu hằng) để GUI lấy dữ liệu hiển thị
    const vector<NoteItem>& getList() const { return list; }

    /**
     * 1. HÀM KIỂM TRA TÍNH HỢP LỆ (VALIDATION)
     * Đảm bảo các dữ liệu đầu vào không bị rỗng và người lập có tồn tại trong hệ thống
     */
    bool validateNote(string ca, string nguoi, string noiDung, string loai) {
        // Kiểm tra cơ bản: Không được để trống các trường quan trọng
        if (noiDung.empty() || ca.empty() || nguoi.empty() || loai.empty()) return false;

        // Kiểm tra phân loại (Fix lỗi C2678 liên quan đến kiểu chuỗi Unicode/L"..." nếu có)
        if (loai != "Thu tuc" && loai != "Giay to" && loai != "Y te" && loai != "Chay no" && loai != "Thue") {
            // Có thể bổ sung logic cảnh báo ở đây nếu cần thiết
        }

        // Gọi sang DataManager để kiểm tra xem "nguoi" (mã NV/QL) có tồn tại trong file CSV gốc không
        if (db == nullptr || !db->isValidUser(nguoi)) {
            return false;
        }

        return true;
    }

    /**
     * 2. XỬ LÝ LƯU GHI CHÚ VÀ CẬP NHẬT GIAO DIỆN
     * Lưu vào file vật lý và đẩy vào mảng động để hiển thị ngay lập tức
     */
    bool addAndSaveNote(string ca, string nguoi, string noiDung, string loai, string thoiGian, string mucDo) {
        // Bước 1: Validate dữ liệu trước khi làm bất cứ việc gì khác
        if (!validateNote(ca, nguoi, noiDung, loai)) {
            return false;
        }

        // Bước 2: Tạo định danh duy nhất (Unique ID) cho ghi chú bằng timestamp
        time_t now = ::time(0);
        string timeStr = to_string(now);
        string maGC = "GC_" + timeStr;

        // Bước 3: Ghi dữ liệu chi tiết vào file "soghichu.csv" (Chế độ Append - ghi tiếp vào cuối)
        ofstream fCsv("soghichu.csv", ios::app);
        if (fCsv.is_open()) {
            // Định dạng lưu: [thời gian, nhãn, ca, người lập, phân loại, mức độ, nội dung]
            fCsv << timeStr << ",GHI_CHU," << ca << "," << nguoi << ","
                << loai << "," << mucDo << "," << noiDung << "\n";
            fCsv.close();
        }

        // Bước 4: Ghi vết (Log) vào file "nhatky.csv" để hệ thống quản lý chung
        ofstream logFile("nhatky.csv", ios::app);
        if (logFile.is_open()) {
            logFile << timeStr << ",GHI_CHU," << maGC << "\n";
            logFile.close();
        }

        // Bước 5: Đưa vào danh sách trong bộ nhớ (vector)
        // Việc này giúp ListView trên giao diện cập nhật ngay mà không cần đọc lại file từ đầu
        NoteItem n = { ca, nguoi, noiDung, loai, thoiGian, mucDo };
        list.push_back(n);

        return true;
    }
};
