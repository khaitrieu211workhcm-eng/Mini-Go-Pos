﻿#pragma once
#include <iostream>
#include <fstream>  // Đọc file
#include <sstream>  // Xử lý chuỗi theo luồng (để cắt chuỗi)
#include <string>
#include <vector>
#include <windows.h> // Sử dụng để hiển thị MessageBox thông báo lỗi

#include "11b_DataManager.h"

using namespace std;

class UploadManager {
private:
    // Con trỏ kết nối đến kho dữ liệu trung tâm để lưu sau khi nạp thành công
    DataManager* db = nullptr;

public:
    // Hàm thiết lập kết nối với DataManager
    void setDataManager(DataManager* manager) { this->db = manager; }

    /**
     * Hàm nạp dữ liệu SẢN PHẨM (8 cột)
     * Đọc file từ đường dẫn filePath và đẩy vào danh sách Product của DataManager
     */
    bool uploadProductData(wstring filePath) {
        if (db == nullptr) return false;

        ifstream file(filePath); // Mở file để đọc
        if (!file.is_open()) return false;

        string line;
        int count = 0; // Đếm số sản phẩm nạp thành công
        while (getline(file, line)) {
            if (line.empty()) continue; // Bỏ qua dòng trống

            // Chuẩn hóa: Nếu file dùng dấu ';' để phân cách thì đổi hết thành dấu ','
            for (char& c : line) if (c == ';') c = ',';

            stringstream ss(line);
            string item;
            vector<string> tokens; // Mảng chứa các từ đã cắt từ dòng

            // Cắt dòng dựa trên dấu phẩy (CSV)
            while (getline(ss, item, ',')) {
                // Xử lý Trim: Xóa khoảng trắng thừa ở đầu và cuối mỗi từ
                size_t start = item.find_first_not_of(" \t\r\n");
                if (start == string::npos) tokens.push_back("");
                else {
                    size_t end = item.find_last_not_of(" \t\r\n");
                    tokens.push_back(item.substr(start, end - start + 1));
                }
            }

            // [NGHIỆP VỤ]: Kiểm tra dòng phải có ít nhất 8 cột dữ liệu
            if (tokens.size() >= 8) {
                Product p;
                p.sku = tokens.at(1);         // Cột 2: Mã SKU
                p.ten = tokens.at(2);         // Cột 3: Tên sản phẩm
                p.khauTru = 0;                // Mặc định nạp vào chưa có khấu trừ
                p.hsd = tokens.at(6);         // Cột 7: Hạn sử dụng

                try {
                    // Chuyển đổi chuỗi sang số (stod cho double, stoi cho int)
                    p.gia = stod(tokens.at(3));    // Cột 4: Giá bán
                    p.tonKho = stoi(tokens.at(4)); // Cột 5: Số lượng tồn kho

                    db->addProduct(p); // Đưa sản phẩm vào RAM (DataManager)
                    count++;
                }
                catch (...) {
                    // Nếu dữ liệu cột giá/số lượng không phải là số -> Bỏ qua dòng này
                    continue;
                }
            }
        }

        file.close();

        // Nếu không nạp được sản phẩm nào (file sai định dạng) -> Báo lỗi
        if (count == 0) {
            MessageBoxW(NULL, L"LỖI SỐ 3: Mở file thành công nhưng không nạp được dữ liệu!", L"Máy Quét Lỗi", MB_OK | MB_ICONERROR);
            return false;
        }

        return true;
    }

    /**
     * Hàm nạp dữ liệu NHÂN SỰ (2 cột: Mã, Chức vụ)
     * Thường dùng để đọc file NhanSu.txt
     */
    bool uploadUserData(wstring filePath) {
        if (db == nullptr) return false;

        ifstream file(filePath);
        if (!file.is_open()) return false;

        string line;
        int count = 0;
        while (getline(file, line)) {
            if (line.empty()) continue;

            for (char& c : line) if (c == ';') c = ',';

            stringstream ss(line);
            string item;
            vector<string> tokens;

            while (getline(ss, item, ',')) {
                size_t start = item.find_first_not_of(" \t\r\n");
                if (start == string::npos) tokens.push_back("");
                else {
                    size_t end = item.find_last_not_of(" \t\r\n");
                    tokens.push_back(item.substr(start, end - start + 1));
                }
            }

            // File Nhân sự yêu cầu tối thiểu 2 cột: [Mã, Vai trò]
            if (tokens.size() >= 2) {
                User u;
                u.ma = tokens.at(0);

                // --- XỬ LÝ BOM (Byte Order Mark) ---
                // Một số file UTF-8 có 3 ký tự lạ ở đầu file, đoạn code này giúp xóa bỏ chúng
                // để so sánh mã nhân viên (như ADMIN) chính xác hơn.
                if (u.ma.size() >= 3 &&
                    (unsigned char)u.ma.at(0) == 0xEF &&
                    (unsigned char)u.ma.at(1) == 0xBB &&
                    (unsigned char)u.ma.at(2) == 0xBF) {
                    u.ma = u.ma.substr(3);
                }

                u.role = tokens.at(1);
                db->addUser(u); // Đưa nhân sự vào RAM
                count++;
            }
        }
        file.close();
        return count > 0;
    }
};
