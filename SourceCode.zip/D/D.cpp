﻿#include <windows.h>    // Thư viện cốt lõi của Windows (quản lý cửa sổ, thông điệp)
#include <gdiplus.h>    // Thư viện đồ họa nâng cao (để vẽ giao diện, logo, màu sắc đẹp hơn)
#include <vector>
#include <string>
#include <commctrl.h>   // Thư viện các trình điều khiển chung (như ListView, Button hiện đại)

// --- NHÚNG TOÀN BỘ CÁC MODULE NGHIỆP VỤ ĐÃ VIẾT ---
#include "11b_DataManager.h"    // Quản lý kho dữ liệu RAM
#include "0b_UploadManager.h"   // Nạp dữ liệu từ file
#include "1b_Transaction.h"     // Lớp cha Giao dịch
#include "2b_Invoice.h"         // Bán hàng
#include "3b_Import.h"          // Nhập kho
#include "4b_Export.h"          // Xuất kho
#include "6b_NoteManager.h"     // Ghi chú
#include "7b_ShiftManager.h"    // Quản lý ca làm việc
#include "8a_DataExporter.h"    // Xuất báo cáo file
#include "12b_SystemManager.h"  // Quản lý nguồn (Bật/Tắt hệ thống)
#include "10b_Controller.h"     // Bộ điều khiển trung tâm (Bộ não)

// --- KHỞI TẠO ĐỐI TƯỢNG TOÀN CỤC ---
// Các đối tượng này tồn tại xuyên suốt vòng đời của ứng dụng
Controller appCtrl;        // Đối tượng điều khiển mọi logic nghiệp vụ
SystemManager sysManager;  // Đối tượng quản lý trạng thái đóng/mở máy

// --- CẤU HÌNH LIÊN KẾT THƯ VIỆN HỆ THỐNG ---
// Lệnh pragma giúp trình biên dịch tự động tìm và nạp các file thư viện .lib cần thiết
#pragma comment (lib, "Gdiplus.lib")   // Liên kết thư viện đồ họa GDI+
#pragma comment (lib, "comctl32.lib")  // Liên kết thư viện Common Controls (ListView, ProgressBar...)

using namespace std;
using namespace Gdiplus; // Sử dụng không gian tên của GDI+ để gọi các hàm đồ họa ngắn gọn hơn


// ============================= ID DINH DANH ============================
#define BTN_POWER 51
#define BTN_BAT_DAU 52 
#define BTN_KET_THUC 53
#define BTN_BAN_HANG 54
#define BTN_NHAP_KHO 55
#define BTN_XUAT_KHO 56
#define BTN_GHI_CHU 57
#define BTN_LUU_XUAT 58     
#define BTN_UPLOAD 59       
#define BTN_KEY_BASE 1000

#define TXT_BH_SKU 401
#define TXT_BH_TEN 402
#define TXT_BH_SL 403
#define TXT_BH_GIA 404
#define TXT_BH_KHAUTRU 405
#define TXT_BH_HSD 406
#define BTN_BH_LUU_KE_TIEP 407
#define LV_BH_LIST 408

#define TXT_NH_SKU 501
#define TXT_NH_TEN 502
#define TXT_NH_SL 503
#define TXT_NH_GIA 504
#define TXT_NH_NCC 505
#define TXT_NH_HSD 506
#define BTN_NH_LUU 507
#define LV_NH_LIST 508

#define TXT_XH_SKU 601
#define TXT_XH_TEN 602
#define TXT_XH_SL 603
#define TXT_XH_GIA 604
#define TXT_XH_LYDO 605
#define TXT_XH_NGAY 606
#define BTN_XH_LUU 607
#define LV_XH_LIST 608

#define TXT_GC_CA 701
#define TXT_GC_NGUOILAP 702
#define TXT_GC_NOIDUNG 703
#define TXT_GC_PHANLOAI 704
#define TXT_GC_THOIGIAN 705
#define TXT_GC_MALK 706
#define BTN_GC_LUU 707
#define LV_GC_LIST 708

#define TXT_MOCA_QL 201
#define TXT_MOCA_NV 202
#define TXT_MOCA_TIENDAU 203
#define TXT_MOCA_TIENKET_DAU 204
#define BTN_MOCA_LUU 205
#define TXT_KETCA_QL 301
#define TXT_KETCA_NV 302
#define TXT_KETCA_TIENKET_CUOI 303
#define TXT_KETCA_DOANHTHU 304
#define TXT_KETCA_CHENHLECH 305
#define TXT_KETCA_GHICHU 306
#define BTN_KETCA_LUU 307

const wchar_t* layout[] = {
    L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", L"9", L"0",
    L"Q", L"W", L"E", L"R", L"T", L"Y", L"U", L"I", L"O", L"P",
    L"A", L"S", L"D", L"F", L"G", L"H", L"J", L"K", L"L", L"Enter",
    L"Z", L"X", L"C", L"V", L"B", L"N", L"M", L"<-", L"Up", L"Dn", L"Lt", L"Rt"
};

// ============================== BIEN TOAN CUC UI ========================

HWND hActiveEdit, hScreenGroup;
HWND hSidebar[10], hSidebarBtns[10];
HWND hKeys[42], hSpaceGroup, hSpaceBtn, hDoanhThuLabel;
HWND hListViewBH, hListViewNH, hListViewXH, hListViewGC;
vector<HWND> hBHInputs, hNHInputs, hXHInputs, hGCInputs, hMoCaInputs, hKetCaInputs;

// ========================= HAM TIEN ICH ================================

/**
 * Hàm RenderListViewColumns: Thiết lập tiêu đề và độ rộng các cột cho bảng (ListView)
 * @param hListView: Handle của bảng cần cấu hình
 * @param cols: Danh sách các tiêu đề cột (dạng chuỗi wide string)
 * @param widths: Danh sách độ rộng tương ứng cho từng cột (đơn vị pixel)
 */
void RenderListViewColumns(HWND hListView, const vector<wstring>& cols, const vector<int>& widths) {

    // 1. Kích hoạt tính năng mở rộng: Hiện đường kẻ bảng (Gridlines) và cho phép chọn cả dòng khi nhấn chuột
    ListView_SetExtendedListViewStyle(hListView, LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

    // 2. Khởi tạo cấu trúc LVCOLUMN để định nghĩa thông số cột
    LVCOLUMN lvc = { 0 };

    // Mask xác định các thuộc tính sẽ được thiết lập: Định dạng, Độ rộng, Văn bản và Chỉ số cột phụ
    lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
    lvc.fmt = LVCFMT_LEFT; // Căn lề trái cho nội dung trong cột

    // 3. Duyệt qua danh sách để chèn từng cột vào bảng
    for (size_t i = 0; i < cols.size(); i++) {
        lvc.iSubItem = (int)i;                  // Chỉ số của cột (từ 0)
        lvc.cx = widths[i];                     // Thiết lập độ rộng pixel từ vector widths
        lvc.pszText = (LPWSTR)cols[i].c_str();  // Gán nội dung tiêu đề từ vector cols

        // Thực hiện lệnh chèn cột vào ListView tại vị trí i
        ListView_InsertColumn(hListView, (int)i, &lvc);
    }
}


void ShowTab(int tab) {
    for (HWND h : hBHInputs) ShowWindow(h, SW_HIDE);
    for (HWND h : hNHInputs) ShowWindow(h, SW_HIDE);
    for (HWND h : hXHInputs) ShowWindow(h, SW_HIDE);
    for (HWND h : hGCInputs) ShowWindow(h, SW_HIDE);
    for (HWND h : hMoCaInputs) ShowWindow(h, SW_HIDE);
    for (HWND h : hKetCaInputs) ShowWindow(h, SW_HIDE);

    ShowWindow(hListViewBH, SW_HIDE); ShowWindow(hListViewNH, SW_HIDE);
    ShowWindow(hListViewXH, SW_HIDE); ShowWindow(hListViewGC, SW_HIDE);


    switch (tab) {
    case BTN_BAN_HANG:
        SetWindowText(hScreenGroup, L"MAN HINH: BAN HANG");
        for (HWND h : hBHInputs) ShowWindow(h, SW_SHOW);
        ShowWindow(hListViewBH, SW_SHOW); break;
    case BTN_NHAP_KHO:
        SetWindowText(hScreenGroup, L"MAN HINH: NHAP KHO");
        for (HWND h : hNHInputs) ShowWindow(h, SW_SHOW); ShowWindow(hListViewNH, SW_SHOW); break;
    case BTN_XUAT_KHO:
        SetWindowText(hScreenGroup, L"MAN HINH: XUAT KHO");
        for (HWND h : hXHInputs) ShowWindow(h, SW_SHOW); ShowWindow(hListViewXH, SW_SHOW); break;
    case BTN_GHI_CHU:
        SetWindowText(hScreenGroup, L"MAN HINH: SO GHI CHU");
        for (HWND h : hGCInputs) ShowWindow(h, SW_SHOW); ShowWindow(hListViewGC, SW_SHOW); break;
    case BTN_BAT_DAU:
        SetWindowText(hScreenGroup, L"MAN HINH: MO CA");
        for (HWND h : hMoCaInputs) ShowWindow(h, SW_SHOW); break;
    case BTN_KET_THUC:
        SetWindowText(hScreenGroup, L"MAN HINH: KET CA");
        for (HWND h : hKetCaInputs) ShowWindow(h, SW_SHOW); break;
    case -1: SetWindowText(hScreenGroup, L""); break;
    }
}

/**
 * Hàm ToggleGUI: Ẩn hoặc hiện toàn bộ các thành phần giao diện chính
 * @param hWnd: Handle của cửa sổ chính
 * @param show: true để hiện giao diện, false để ẩn giao diện
 */
void ToggleGUI(HWND hWnd, bool show) {
    // 1. Xác định lệnh thực hiện: SW_SHOW (Hiển thị) hoặc SW_HIDE (Ẩn)
    int cmd = show ? SW_SHOW : SW_HIDE;

    // 2. Duyệt qua mảng Sidebar: Ẩn/Hiện các Panel và các nút bấm điều hướng (từ chỉ số 1 đến 8)
    for (int i = 1; i < 9; i++) {
        ShowWindow(hSidebar[i], cmd);
        ShowWindow(hSidebarBtns[i], cmd);
    }

    // 3. Duyệt qua mảng bàn phím ảo: Ẩn/Hiện toàn bộ 42 phím bấm
    for (int i = 0; i < 42; i++) ShowWindow(hKeys[i], cmd);

    // 4. Ẩn/Hiện các thành phần bổ trợ khác:
    ShowWindow(hSpaceGroup, cmd);     // Nhóm phím cách (Space)
    ShowWindow(hSpaceBtn, cmd);       // Nút phím cách
    ShowWindow(hDoanhThuLabel, cmd);  // Nhãn hiển thị doanh thu
    ShowWindow(hScreenGroup, cmd);    // Vùng hiển thị nội dung chính (Screen)

    // 5. Logic bổ sung khi TẮT giao diện:
    // Gọi ShowTab(-1) để đóng tất cả các tab đang mở, đưa về trạng thái trống
    if (!show) ShowTab(-1);

    // 6. Yêu cầu hệ thống vẽ lại cửa sổ chính để cập nhật thay đổi hình ảnh ngay lập tức
    InvalidateRect(hWnd, NULL, TRUE);
}


void DrawLargeLogo(Graphics& g, int centerX, int centerY, int baseSize) {
    float size = (float)baseSize * 4.0f;
    g.SetSmoothingMode(SmoothingModeAntiAlias);
    SolidBrush redBrush(Color(255, 230, 0, 0));
    g.FillEllipse(&redBrush, (float)centerX - size / 2.0f, (float)centerY - size / 2.0f, size, size);

    FontFamily fontFamily(L"Segoe UI");
    Font goFont(&fontFamily, size / 2.2f, FontStyleBold, UnitPixel);
    SolidBrush whiteBrush(Color(255, 255, 255, 255));

    StringFormat format;
    format.SetAlignment(StringAlignmentCenter);
    format.SetLineAlignment(StringAlignmentCenter);

    RectF rectGo((float)centerX - size / 2.0f, (float)centerY - size / 2.0f, size, size);
    g.DrawString(L"GO", -1, &goFont, rectGo, &format, &whiteBrush);
}

// =============================== WNDPROC =============================
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: {
        InitCommonControls();
        const wchar_t* sbT[] = { L"Power", L"File", L"Upload", L"Mo Ca", L"Ket Ca", L"Ban Hang", L"Nhap Kho", L"Xuat Kho", L"Ghi Chu" };
        const wchar_t* btnT[] = { L"ON/OFF", L"LUU/XUAT", L"NAP DU LIEU", L"BAT DAU", L"KET THUC", L"BAN HANG", L"NHAP KHO", L"XUAT KHO", L"GHI CHU" };
        const HMENU ids[] = { (HMENU)BTN_POWER, (HMENU)BTN_LUU_XUAT, (HMENU)BTN_UPLOAD, (HMENU)BTN_BAT_DAU, (HMENU)BTN_KET_THUC, (HMENU)BTN_BAN_HANG, (HMENU)BTN_NHAP_KHO, (HMENU)BTN_XUAT_KHO, (HMENU)BTN_GHI_CHU };

        for (int i = 0; i < 9; i++) {
            hSidebar[i] = CreateWindow(L"BUTTON", sbT[i], WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hWnd, NULL, NULL, NULL);
            hSidebarBtns[i] = CreateWindow(L"BUTTON", btnT[i], WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hWnd, ids[i], NULL, NULL);
        }
        hScreenGroup = CreateWindow(L"BUTTON", L"MAN HINH: CHO", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hWnd, NULL, NULL, NULL);

        // ============================TAB BAN HANG=============================
        const wchar_t* bhl[] = { L"Ma SKU:", L"Ten Hang:", L"So Luong:", L"Don Gia:", L"Khau Tru:", L"HSD:" };
        HMENU bhi[] = { (HMENU)TXT_BH_SKU, (HMENU)TXT_BH_TEN, (HMENU)TXT_BH_SL, (HMENU)TXT_BH_GIA, (HMENU)TXT_BH_KHAUTRU, (HMENU)TXT_BH_HSD };
        for (int i = 0; i < 6; i++) {
            hBHInputs.push_back(CreateWindow(L"STATIC", bhl[i], WS_CHILD, 0, 0, 0, 0, hWnd, NULL, NULL, NULL));
            hBHInputs.push_back(CreateWindow(L"EDIT", L"", WS_CHILD | WS_BORDER | (i == 1 || i >= 3 ? ES_READONLY : 0), 0, 0, 0, 0, hWnd, bhi[i], NULL, NULL));
        }
        hBHInputs.push_back(CreateWindow(L"BUTTON", L"LUU KE TIEP", WS_CHILD, 0, 0, 0, 0, hWnd, (HMENU)BTN_BH_LUU_KE_TIEP, NULL, NULL));

        // ========================TAB NHAP KHO ===============================
        const wchar_t* nhl[] = { L"Ma SKU:", L"Ten Hang:", L"SL Nhap:", L"Gia Nhap:", L"Nha CC:", L"HSD:" };
        HMENU nhi[] = { (HMENU)TXT_NH_SKU, (HMENU)TXT_NH_TEN, (HMENU)TXT_NH_SL, (HMENU)TXT_NH_GIA, (HMENU)TXT_NH_NCC, (HMENU)TXT_NH_HSD };
        for (int i = 0; i < 6; i++) {
            hNHInputs.push_back(CreateWindow(L"STATIC", nhl[i], WS_CHILD, 0, 0, 0, 0, hWnd, NULL, NULL, NULL));
            hNHInputs.push_back(CreateWindow(L"EDIT", L"", WS_CHILD | WS_BORDER, 0, 0, 0, 0, hWnd, nhi[i], NULL, NULL));
        }
        hNHInputs.push_back(CreateWindow(L"BUTTON", L"LUU NHAP KHO", WS_CHILD, 0, 0, 0, 0, hWnd, (HMENU)BTN_NH_LUU, NULL, NULL));
        // ========================= TAB XUAT KHO ===========================
        const wchar_t* xhl[] = { L"Ma SKU:", L"Ten Hang:", L"SL Xuat:", L"Gia Tri:", L"Ly Do:", L"Ngay Xuat:" };
        HMENU xhi[] = { (HMENU)TXT_XH_SKU, (HMENU)TXT_XH_TEN, (HMENU)TXT_XH_SL, (HMENU)TXT_XH_GIA, (HMENU)TXT_XH_LYDO, (HMENU)TXT_XH_NGAY };

        for (int i = 0; i < 6; i++) {
            hXHInputs.push_back(CreateWindow(L"STATIC", xhl[i], WS_CHILD, 0, 0, 0, 0, hWnd, NULL, NULL, NULL));

            // Dùng EDIT thường cho tất cả các ô để bàn phím ảo POS hoạt động mượt mà
            int style = WS_CHILD | WS_BORDER | ES_AUTOHSCROLL;

            // Tự động KHÓA "Chỉ đọc" cho ô Tên Hàng (i==1) và Giá Trị (i==3) 
            // vì 2 ô này hệ thống sẽ tự động điền khi gõ xong SKU
            if (i == 1 || i == 3) {
                style |= ES_READONLY;
            }

            hXHInputs.push_back(CreateWindow(L"EDIT", L"", style, 0, 0, 0, 0, hWnd, xhi[i], NULL, NULL));
        }
        hXHInputs.push_back(CreateWindow(L"BUTTON", L"LUU XUAT KHO", WS_CHILD, 0, 0, 0, 0, hWnd, (HMENU)BTN_XH_LUU, NULL, NULL));

        // ===========================TAB GHI CHU===========================
        const wchar_t* gcl[] = { L"Ca Lam:", L"Nguoi Lap:", L"Noi Dung:", L"Phan Loai:", L"Thoi Gian:", L"Ma LK:" };
        HMENU gci[] = { (HMENU)TXT_GC_CA, (HMENU)TXT_GC_NGUOILAP, (HMENU)TXT_GC_NOIDUNG, (HMENU)TXT_GC_PHANLOAI, (HMENU)TXT_GC_THOIGIAN, (HMENU)TXT_GC_MALK };

        for (int i = 0; i < 6; i++) {
            hGCInputs.push_back(CreateWindow(L"STATIC", gcl[i], WS_CHILD, 0, 0, 0, 0, hWnd, NULL, NULL, NULL));

            // XÓA BỎ COMBOBOX! Dùng EDIT thường cho TẤT CẢ các ô 

            hGCInputs.push_back(CreateWindow(L"EDIT", L"", WS_CHILD | WS_BORDER | ES_AUTOHSCROLL, 0, 0, 0, 0, hWnd, gci[i], NULL, NULL));
        }

        hGCInputs.push_back(CreateWindow(L"BUTTON", L"LUU GHI CHU", WS_CHILD, 0, 0, 0, 0, hWnd, (HMENU)BTN_GC_LUU, NULL, NULL));
        // KHOI TAO LISTVIEWS VOI DUONG LUOI (GRIDLINES)
        hListViewBH = CreateWindow(WC_LISTVIEW, L"", WS_CHILD | WS_BORDER | LVS_REPORT, 0, 0, 0, 0, hWnd, (HMENU)LV_BH_LIST, NULL, NULL);
        hListViewNH = CreateWindow(WC_LISTVIEW, L"", WS_CHILD | WS_BORDER | LVS_REPORT, 0, 0, 0, 0, hWnd, (HMENU)LV_NH_LIST, NULL, NULL);
        hListViewXH = CreateWindow(WC_LISTVIEW, L"", WS_CHILD | WS_BORDER | LVS_REPORT, 0, 0, 0, 0, hWnd, (HMENU)LV_XH_LIST, NULL, NULL);
        hListViewGC = CreateWindow(WC_LISTVIEW, L"", WS_CHILD | WS_BORDER | LVS_REPORT, 0, 0, 0, 0, hWnd, (HMENU)LV_GC_LIST, NULL, NULL);

        RenderListViewColumns(hListViewBH, { L"STT", L"SKU", L"Ten Hang", L"SL", L"Gia", L"KT", L"HSD", L"Tong" }, { 40, 70, 150, 50, 80, 50, 90, 100 });
        RenderListViewColumns(hListViewNH, { L"STT", L"SKU", L"Ten Hang", L"SL", L"Gia", L"KT", L"HSD", L"Tong" }, { 40, 70, 150, 50, 80, 50, 90, 100 });
        RenderListViewColumns(hListViewXH, { L"STT", L"SKU", L"Ten Hang", L"SL", L"Gia", L"KT", L"HSD", L"Tong" }, { 40, 70, 150, 50, 80, 50, 90, 100 });
        RenderListViewColumns(hListViewGC, { L"STT", L"Ca", L"Nguoi lap", L"Loai", L"Time", L"Noi dung", L"Ma LK" }, { 40, 60, 100, 80, 80, 150, 80 });

        // ========================== MO/KET CA ======================
        const wchar_t* mcl[] = { L"Ma QL:", L"Ma NV:", L"Tien dau:", L"Tien ket:" };
        HMENU mci[] = { (HMENU)TXT_MOCA_QL, (HMENU)TXT_MOCA_NV, (HMENU)TXT_MOCA_TIENDAU, (HMENU)TXT_MOCA_TIENKET_DAU };
        for (int i = 0; i < 4; i++) {
            hMoCaInputs.push_back(CreateWindow(L"STATIC", mcl[i], WS_CHILD, 0, 0, 0, 0, hWnd, NULL, NULL, NULL));
            hMoCaInputs.push_back(CreateWindow(L"EDIT", L"", WS_CHILD | WS_BORDER, 0, 0, 0, 0, hWnd, mci[i], NULL, NULL));
        }
        hMoCaInputs.push_back(CreateWindow(L"BUTTON", L"LUU MO CA", WS_CHILD, 0, 0, 0, 0, hWnd, (HMENU)BTN_MOCA_LUU, NULL, NULL));

        const wchar_t* kcl[] = { L"Ma QL:", L"Ma NV:", L"Tien ket:", L"Doanh thu:", L"Chenh lech:", L"Ghi chu:" };
        HMENU kci[] = { (HMENU)TXT_KETCA_QL, (HMENU)TXT_KETCA_NV, (HMENU)TXT_KETCA_TIENKET_CUOI, (HMENU)TXT_KETCA_DOANHTHU, (HMENU)TXT_KETCA_CHENHLECH, (HMENU)TXT_KETCA_GHICHU };
        for (int i = 0; i < 6; i++) {
            hKetCaInputs.push_back(CreateWindow(L"STATIC", kcl[i], WS_CHILD, 0, 0, 0, 0, hWnd, NULL, NULL, NULL));
            hKetCaInputs.push_back(CreateWindow(L"EDIT", L"", WS_CHILD | WS_BORDER, 0, 0, 0, 0, hWnd, kci[i], NULL, NULL));
        }
        hKetCaInputs.push_back(CreateWindow(L"BUTTON", L"LUU KET CA", WS_CHILD, 0, 0, 0, 0, hWnd, (HMENU)BTN_KETCA_LUU, NULL, NULL));

        for (int i = 0; i < 42; i++) hKeys[i] = CreateWindow(L"BUTTON", layout[i], WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hWnd, (HMENU)(size_t)(BTN_KEY_BASE + i), NULL, NULL);
        hSpaceGroup = CreateWindow(L"BUTTON", L"Space", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hWnd, NULL, NULL, NULL);
        hSpaceBtn = CreateWindow(L"BUTTON", L"SPACE", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hWnd, (HMENU)(size_t)(BTN_KEY_BASE + 99), NULL, NULL);
        hDoanhThuLabel = CreateWindow(L"STATIC", L"DOANH THU: 0", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hWnd, NULL, NULL, NULL);

        ToggleGUI(hWnd, false);
        break;
    }
    case WM_SIZE: {
        int w = LOWORD(lp), h = HIWORD(lp), sbW = 165;
        for (int i = 0; i < 9; i++) {
            MoveWindow(hSidebar[i], 5, i * 70 + 5, sbW - 10, 65, TRUE);
            MoveWindow(hSidebarBtns[i], 15, i * 70 + 25, sbW - 30, 35, TRUE);
        }
        int mX = sbW + 5, mW = w - mX - 5, scrH = 450;
        MoveWindow(hScreenGroup, mX, 5, mW, scrH, TRUE);

        auto arrange = [&](vector<HWND>& inputs, HWND lv) {
            for (int i = 0; i < 6; i++) {
                MoveWindow(inputs[i * 2], mX + 15, 30 + i * 42, 100, 20, TRUE);
                MoveWindow(inputs[i * 2 + 1], mX + 15, 50 + i * 42, 200, 25, TRUE);
            }
            MoveWindow(inputs.back(), mX + 15, scrH - 50, 200, 40, TRUE);
            MoveWindow(lv, mX + 230, 25, mW - 245, scrH - 35, TRUE);
            };

        arrange(hBHInputs, hListViewBH); arrange(hNHInputs, hListViewNH); arrange(hXHInputs, hListViewXH);
        arrange(hGCInputs, hListViewGC);

        for (int i = 0; i < 4; i++) {
            MoveWindow(hMoCaInputs[i * 2], mX + 20, 35 + i * 35, 100, 20, TRUE);
            MoveWindow(hMoCaInputs[i * 2 + 1], mX + 130, 33 + i * 35, 180, 25, TRUE);
        }
        MoveWindow(hMoCaInputs.back(), mX + mW - 140, scrH - 55, 120, 40, TRUE);

        for (int i = 0; i < 6; i++) {
            MoveWindow(hKetCaInputs[i * 2], mX + 20, 30 + i * 30, 100, 20, TRUE);
            MoveWindow(hKetCaInputs[i * 2 + 1], mX + 130, 28 + i * 30, 180, 25, TRUE);
        }
        MoveWindow(hKetCaInputs.back(), mX + mW - 140, scrH - 55, 120, 40, TRUE);

        int kY = scrH + 10, kw = mW / 10, kh = (h - kY - 95) / 5;
        for (int i = 0; i < 42; i++) MoveWindow(hKeys[i], mX + (i % 10) * kw, kY + (i / 10) * kh, kw - 2, kh - 2, TRUE);
        MoveWindow(hSpaceGroup, mX, h - 85, mW, 55, TRUE);
        MoveWindow(hSpaceBtn, mX + 10, h - 65, mW - 20, 30, TRUE);
        MoveWindow(hDoanhThuLabel, w - 200, h - 25, 180, 20, TRUE);
        break;
    }
    case WM_COMMAND: {
        int id = LOWORD(wp);

        // ====================================================================
        if (id >= BTN_BAT_DAU && id <= BTN_GHI_CHU) {
            ShowTab(id);                // 1. GUI tự hiển thị màn hình mới
            appCtrl.switchTab(id);      // 2. Controller tự đổi con trỏ đa hình tương ứng
        }

        // ====================================================================
        if (id == BTN_POWER) {
            // 1. Kiểm tra trạng thái máy TRƯỚC KHI bấm
            bool wasOn = sysManager.getStatus();

            // 2. Gọi hàm bật/tắt (hệ thống tự động lưu ngầm bên trong 12b nếu đang ON)
            bool isTurnedOn = sysManager.togglePower(&appCtrl);

            // 3. Nếu đang ON mà chuyển thành OFF -> Hiển thị "Đã lưu" theo đúng Lưu đồ [1]
            if (wasOn == true && isTurnedOn == false) {
                MessageBox(hWnd, L"Đã lưu tự động tất cả dữ liệu đang chạy!", L"Hệ Thống", MB_OK | MB_ICONINFORMATION);
            }

            // 4. Cập nhật lại giao diện (Ẩn hết nếu tắt, hiện nếu bật)
            ToggleGUI(hWnd, sysManager.getStatus());
        }
        // ===============BTN_LUU_XUAT=====================================
        if (id == BTN_LUU_XUAT) {
            OPENFILENAME ofn;
            wchar_t szFile[MAX_PATH] = L"NhatKy";

            ZeroMemory(&ofn, sizeof(ofn));
            ofn.lStructSize = sizeof(ofn);
            ofn.hwndOwner = hWnd;
            ofn.lpstrFile = szFile;
            ofn.nMaxFile = sizeof(szFile) / sizeof(wchar_t); // Khai báo đúng kích thước buffer

            //  Giới hạn người dùng CHỈ ĐƯỢC CHỌN TXT hoặc CSV theo Lưu đồ đồ án
            ofn.lpstrFilter = L"File CSV (*.csv)\0*.csv\0File TXT (*.txt)\0*.txt\0";
            ofn.nFilterIndex = 1; // Mặc định hiển thị ưu tiên .csv

            // Tiêu đề hướng dẫn người dùng trực quan trên hộp thoại
            ofn.lpstrTitle = L"BƯỚC 1: Chọn Thư mục (X)  |  BƯỚC 2: Nhập đúng ô File Name (NhatKy, HoaDon, NhapKho, XuatKho, GhiChu)";
            ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;

            // Nếu người dùng nhấn "Save / Xác nhận Export"
            if (GetSaveFileName(&ofn)) {

                // 1. Chuyển đổi đường dẫn file từ WCHAR sang string tiêu chuẩn
                wstring ws(szFile);
                string fullPath(ws.begin(), ws.end());

                // 2. Xác định "Định dạng" dựa vào tuỳ chọn (Filter) của người dùng
                string dinhDang = (ofn.nFilterIndex == 1) ? "CSV" : "TXT";

                // 3. Phân tách đường dẫn để lấy "Thư mục (X)" và "Loại dữ liệu"
                string thuMuc = "";
                string loaiDuLieu = "";

                size_t lastSlash = fullPath.find_last_of("\\/");
                size_t lastDot = fullPath.find_last_of(".");

                if (lastSlash != string::npos && lastDot != string::npos) {
                    thuMuc = fullPath.substr(0, lastSlash); // Tách lấy đoạn C:\Export
                    loaiDuLieu = fullPath.substr(lastSlash + 1, lastDot - lastSlash - 1); // Tách lấy từ NhatKy
                }
                else {
                    thuMuc = fullPath; // Backup an toàn nếu không có dấu chấm
                    loaiDuLieu = "NhatKy";
                }

                // 4. GUI GỌI HÀM LOGIC (MVC-Lite): Truyền đúng 3 tham số vào lớp DataExporter
                if (appCtrl.exporter.exportFile(loaiDuLieu, dinhDang, thuMuc)) {
                    MessageBox(hWnd, L"Xuất dữ liệu thành công ra thư mục đã chọn!", L"Hoàn tất", MB_OK | MB_ICONINFORMATION);
                }
                else {
                    MessageBox(hWnd, L"Lỗi: Không có dữ liệu hoặc sai Loại Dữ Liệu (Phải là: NhatKy, HoaDon, NhapKho...)!", L"Lỗi Xuất File", MB_ICONERROR);
                }
            }
        }

        // ========================BTN_UPLOAD==================================

        if (id == BTN_UPLOAD) {
            OPENFILENAME ofn;
            wchar_t szFile[MAX_PATH] = { 0 };
            ZeroMemory(&ofn, sizeof(ofn));
            ofn.lStructSize = sizeof(ofn);
            ofn.hwndOwner = hWnd;
            ofn.lpstrFile = szFile;
            ofn.nMaxFile = MAX_PATH;
            ofn.lpstrFilter = L"Data Files (*.csv; *.txt)\0*.csv;*.txt\0All Files (*.*)\0*.*\0";
            ofn.nFilterIndex = 1;
            ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

            if (GetOpenFileName(&ofn)) {
                wstring ws(szFile); // Lấy đường dẫn thực tế từ hộp thoại

                // 1. Nếu tên file có chứa chữ "NhanSu" -> Gọi hàm nạp file 2 cột
                if (ws.find(L"NhanSu") != wstring::npos) {
                    if (appCtrl.uploadObj.uploadUserData(ws)) {
                        MessageBoxW(hWnd, L"Nạp danh sách NHÂN SỰ thành công!", L"Thông Báo", MB_OK | MB_ICONINFORMATION);
                    }
                }
                // 2. Ngược lại (nếu chọn file List.txt) -> Gọi hàm nạp file 8 cột
                else {
                    if (appCtrl.uploadObj.uploadProductData(ws)) {
                        MessageBoxW(hWnd, L"Nạp dữ liệu HÀNG HÓA thành công!", L"Thông Báo", MB_OK | MB_ICONINFORMATION);
                    }
                }
            }
        }
        // Hàm lambda phụ trợ giúp lấy chữ từ ô nhập nhanh gọn
        auto GetStrFromHWND = [](HWND h) {
            // [CHÚ Ý]: Tự tay gõ ngoặc vuông bọc số 256 nếu web vẫn xóa nhé!
            wchar_t buf[256] = { 0 };
            GetWindowTextW(h, buf, 256);
            wstring ws(buf);
            return string(ws.begin(), ws.end());
            };
        // ======================BTN_MOCA_LUU=============================
        if (id == BTN_MOCA_LUU) {
            // Đã fix chuẩn vị trí các ô trắng theo quy luật xen kẽ
            string ql = GetStrFromHWND(hMoCaInputs.at(1));       // Ô Mã QL
            string nv = GetStrFromHWND(hMoCaInputs.at(3));       // Ô Mã NV
            string tienDau = GetStrFromHWND(hMoCaInputs.at(5));  // Ô Tiền đầu
            string tienKet = GetStrFromHWND(hMoCaInputs.at(7));  // Ô Tiền két

            if (appCtrl.shift.saveMoCa(ql, nv, tienDau, tienKet)) {
                MessageBoxW(hWnd, L"Mở ca thành công! Đã ghi nhật ký.", L"Thành công", MB_OK | MB_ICONINFORMATION);
            }
            else {
                MessageBoxW(hWnd, L"LỖI: Sai định dạng số, bỏ trống, hoặc Mã QL/NV không tồn tại! Yêu cầu nhập lại.", L"Lỗi Validate", MB_OK | MB_ICONERROR);
            }
        }
        // ===================BTN_KETCA_LUU=========================

        if (id == BTN_KETCA_LUU) {
            // Lấy 6 chuỗi dữ liệu từ các ô trắng (Edit Control) theo quy luật số lẻ
            string ql = GetStrFromHWND(hKetCaInputs.at(1));         // Ô Mã QL
            string nv = GetStrFromHWND(hKetCaInputs.at(3));         // Ô Mã NV
            string tienKet = GetStrFromHWND(hKetCaInputs.at(5));    // Ô Tiền két
            string doanhThu = GetStrFromHWND(hKetCaInputs.at(7));   // Ô Doanh thu
            string chenhLech = GetStrFromHWND(hKetCaInputs.at(9));  // Ô Chênh lệch
            string ghiChu = GetStrFromHWND(hKetCaInputs.at(11));    // Ô Ghi chú

            // Truyền xuống Controller xử lý [1]
            if (appCtrl.shift.saveKetCa(ql, nv, tienKet, doanhThu, chenhLech, ghiChu)) {
                MessageBoxW(hWnd, L"Kết ca thành công! Đã ghi nhật ký.", L"Thành công", MB_OK | MB_ICONINFORMATION);
            }
            else {
                MessageBoxW(hWnd, L"LỖI: Sai định dạng số, bỏ trống, hoặc Mã QL/NV không tồn tại! Yêu cầu nhập lại.", L"Lỗi Validate", MB_OK | MB_ICONERROR);
            }
        }

        // ============HÀM LAMBDA TRỢ GIÚP TÍNH TỔNG TIỀN====================

        auto UpdateTongTien = [](HWND hLV, HWND hLabel) {
            int count = ListView_GetItemCount(hLV);
            double total = 0.0;
            for (int i = 0; i < count; i++) {
                // Tự gõ tay cặp ngoặc vuông nếu web bị nuốt ký tự nhé
                wchar_t itemTong[256] = { 0 };
                ListView_GetItemText(hLV, i, 7, itemTong, 256); // Cột 7 là Tổng
                total += _wtof(itemTong);
            }
            wstring txt = L"TỔNG TIỀN: " + to_wstring(total);
            SetWindowTextW(hLabel, txt.c_str());
            };

        // ==========SỰ KIỆN: NHẬP & THÊM VÀO LISTVIEW =======================
        // VÀ SỬA NÓ THÀNH NHƯ THẾ NÀY:
        if (id == 1029 && IsWindowVisible(hListViewBH)) {
            string sku = GetStrFromHWND(hBHInputs.at(1));   // Lấy ô SKU
            string slStr = GetStrFromHWND(hBHInputs.at(5)); // Lấy ô Số Lượng

            // 1. Validate: Không rỗng
            if (sku.empty() || slStr.empty()) {
                MessageBoxW(hWnd, L"LỖI: Vui lòng nhập SKU và Số lượng!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0; // Trả về ngay, KHÔNG cho hiển thị ListView
            }

            // 2. Validate: Tồn tại SKU & Đúng định dạng số
            if (!appCtrl.db.isValidSKU(sku)) {
                MessageBoxW(hWnd, L"LỖI: SKU không tồn tại trong hệ thống!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            int sl = 0;
            try { sl = stoi(slStr); }
            catch (...) {
                MessageBoxW(hWnd, L"LỖI: Số lượng phải là chữ số hợp lệ!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            Product p = appCtrl.db.getProductInfo(sku);

            // 3. Validate: Số lượng > 0 và <= Tồn kho
            if (sl <= 0 || sl > p.tonKho) {
                MessageBoxW(hWnd, L"LỖI: Số lượng không hợp lệ (Phải > 0 và <= Tồn kho)!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            // 4. Nếu HỢP LỆ -> Tự động Fill thông tin lên giao diện (HSD, Khấu trừ Auto)
            SetWindowTextA(hBHInputs.at(3), p.ten.c_str());
            SetWindowTextA(hBHInputs.at(7), to_string(p.gia).c_str());
            SetWindowTextA(hBHInputs.at(9), to_string(p.khauTru).c_str());
            SetWindowTextA(hBHInputs.at(11), p.hsd.c_str());

            double thanhTien = (sl * p.gia) - p.khauTru;

            // 5. Kiểm tra xem SKU đã có trong ListView chưa?
            int itemCount = ListView_GetItemCount(hListViewBH);
            bool isExist = false;

            for (int i = 0; i < itemCount; i++) {
                wchar_t itemSKU[256] = { 0 };
                ListView_GetItemText(hListViewBH, i, 1, itemSKU, 256);
                wstring wsSKU(itemSKU);
                string currentSKU(wsSKU.begin(), wsSKU.end());

                if (currentSKU == sku) {
                    // ĐÃ TỒN TẠI -> Cộng dồn Số lượng & Thành tiền
                    wchar_t itemSL[256] = { 0 };
                    ListView_GetItemText(hListViewBH, i, 3, itemSL, 256);
                    int oldSL = _wtoi(itemSL);
                    int newSL = oldSL + sl;

                    // Validate kiểm tra lại tồn kho một lần nữa khi cộng dồn
                    if (newSL > p.tonKho) {
                        MessageBoxW(hWnd, L"LỖI: Tổng số lượng cộng dồn vượt quá tồn kho cho phép!", L"Lỗi", MB_OK | MB_ICONERROR);
                        return 0;
                    }

                    double newTong = (newSL * p.gia) - p.khauTru;

                    // Cập nhật lại giao diện dòng đã có
                    wstring wsNewSL = to_wstring(newSL);
                    wstring wsNewTong = to_wstring(newTong);
                    ListView_SetItemText(hListViewBH, i, 3, (LPWSTR)wsNewSL.c_str());
                    ListView_SetItemText(hListViewBH, i, 7, (LPWSTR)wsNewTong.c_str());

                    isExist = true;
                    break;
                }
            }

            // 6. CHƯA TỒN TẠI -> Tạo dòng mới với STT tịnh tiến
            if (!isExist) {
                int newRow = itemCount;
                wstring wsSTT = to_wstring(newRow + 1);
                wstring wSku = wstring(sku.begin(), sku.end());
                wstring wTen = wstring(p.ten.begin(), p.ten.end());
                wstring wSl = to_wstring(sl);
                wstring wGia = to_wstring(p.gia);
                wstring wKt = to_wstring(p.khauTru);
                wstring wHsd = wstring(p.hsd.begin(), p.hsd.end());
                wstring wTong = to_wstring(thanhTien);

                LVITEMW lvi = { 0 };
                lvi.mask = LVIF_TEXT;
                lvi.iItem = newRow;
                lvi.iSubItem = 0;
                lvi.pszText = (LPWSTR)wsSTT.c_str();
                ListView_InsertItem(hListViewBH, &lvi);

                ListView_SetItemText(hListViewBH, newRow, 1, (LPWSTR)wSku.c_str());
                ListView_SetItemText(hListViewBH, newRow, 2, (LPWSTR)wTen.c_str());
                ListView_SetItemText(hListViewBH, newRow, 3, (LPWSTR)wSl.c_str());
                ListView_SetItemText(hListViewBH, newRow, 4, (LPWSTR)wGia.c_str());
                ListView_SetItemText(hListViewBH, newRow, 5, (LPWSTR)wKt.c_str());
                ListView_SetItemText(hListViewBH, newRow, 6, (LPWSTR)wHsd.c_str());
                ListView_SetItemText(hListViewBH, newRow, 7, (LPWSTR)wTong.c_str());
            }

            // 7. Cập nhật lại Tổng tiền (Gọi hàm Lambda ở trên)
            UpdateTongTien(hListViewBH, hDoanhThuLabel);

            // Xóa rỗng 2 ô nhập liệu để người dùng scan mã tiếp theo
            SetWindowTextW(hBHInputs.at(1), L"");
            SetWindowTextW(hBHInputs.at(5), L"");
        }

        // =============SỰ KIỆN: XÓA DÒNG TRONG LISTVIEW=================
        if (id == 1037 && IsWindowVisible(hListViewBH)) {
            // Lấy dòng đang được chọn (bôi xanh)
            int selIndex = ListView_GetNextItem(hListViewBH, -1, LVNI_SELECTED);
            if (selIndex != -1) {
                // Xóa dòng
                ListView_DeleteItem(hListViewBH, selIndex);

                // Cập nhật lại toàn bộ Cột STT (Để luôn là 1, 2, 3...)
                int count = ListView_GetItemCount(hListViewBH);
                for (int i = 0; i < count; i++) {
                    wstring wsSTT = to_wstring(i + 1);
                    ListView_SetItemText(hListViewBH, i, 0, (LPWSTR)wsSTT.c_str());
                }

                // Tính lại Tổng tiền
                UpdateTongTien(hListViewBH, hDoanhThuLabel);
            }
            else {
                MessageBoxW(hWnd, L"Vui lòng chọn 1 sản phẩm trong bảng để xóa!", L"Thông báo", MB_OK | MB_ICONWARNING);
            }
        }
        // ===SỰ KIỆN: LƯU HÓA ĐƠN & GHI NHẬT KÝ============================
        if (id == BTN_BH_LUU_KE_TIEP) {
            int itemCount = ListView_GetItemCount(hListViewBH);

            // Rule 1: ListView rỗng -> Cảnh báo, không cho lưu
            if (itemCount == 0) {
                MessageBoxW(hWnd, L"LỖI: Hóa đơn trống! Vui lòng nhập hàng hóa trước khi lưu.", L"Lỗi", MB_OK | MB_ICONERROR);
                return 0;
            }

            // Rule 2: Ép dữ liệu tạm từ GUI xuống Controller (InvoiceObj)
            for (int i = 0; i < itemCount; i++) {
                // Chú ý: Tự tay gõ ngoặc vuông và số 256 nếu web bị nuốt mất nhé!
                wchar_t wSku[256] = { 0 }, wTen[256] = { 0 }, wSl[256] = { 0 }, wGia[256] = { 0 }, wKt[256] = { 0 }, wHsd[256] = { 0 }, wTong[256] = { 0 };

                ListView_GetItemText(hListViewBH, i, 1, wSku, 256);
                ListView_GetItemText(hListViewBH, i, 2, wTen, 256);
                ListView_GetItemText(hListViewBH, i, 3, wSl, 256);
                ListView_GetItemText(hListViewBH, i, 4, wGia, 256);
                ListView_GetItemText(hListViewBH, i, 5, wKt, 256);
                ListView_GetItemText(hListViewBH, i, 6, wHsd, 256);
                ListView_GetItemText(hListViewBH, i, 7, wTong, 256);

                // Chốt chuỗi vào 1 biến cố định trước
                wstring wsSku(wSku);
                wstring wsTen(wTen);
                wstring wsHsd(wHsd);

                Item itm;
                itm.sku = string(wsSku.begin(), wsSku.end());
                itm.ten = string(wsTen.begin(), wsTen.end());
                itm.sl = _wtoi(wSl);
                itm.gia = _wtof(wGia);
                itm.khauTru = _wtof(wKt);
                itm.hsd = string(wsHsd.begin(), wsHsd.end());
                itm.tong = _wtof(wTong);

                // Ném Item vào mảng 'list' của Transaction
                appCtrl.invoiceObj.addTempItem(itm);
            }

            // Kích hoạt đa hình lưu file tự động thông qua class cha
            appCtrl.switchTab(BTN_BAN_HANG);
            if (appCtrl.processSaveTransaction()) {
                MessageBoxW(hWnd, L"Tạo hóa đơn thành công! Đã ghi file hoadon.csv và nhatky.csv", L"Thành công", MB_OK | MB_ICONINFORMATION);

                // Xóa trắng giao diện, reset bảng, đưa tổng tiền về 0
                ListView_DeleteAllItems(hListViewBH);
                SetWindowTextW(hDoanhThuLabel, L"DOANH THU: 0");
                for (int i = 1; i <= 11; i += 2) SetWindowTextW(hBHInputs.at(i), L"");
            }
            else {
                MessageBoxW(hWnd, L"Lỗi hệ thống khi lưu file! Vui lòng thử lại.", L"Lỗi", MB_OK | MB_ICONERROR);
            }
        }


        // ======SỰ KIỆN: NHẬP & THÊM VÀO LISTVIEW NHẬP KHO===============
        if (id == 1029 && IsWindowVisible(hListViewNH)) { // Chỉ chạy khi đang ở tab Nhập Kho
            // Lấy dữ liệu từ các ô trắng (Theo quy luật số lẻ: 1, 3, 5, 7, 9, 11)
            string sku = GetStrFromHWND(hNHInputs.at(1));
            string ten = GetStrFromHWND(hNHInputs.at(3));
            string slStr = GetStrFromHWND(hNHInputs.at(5));
            string giaStr = GetStrFromHWND(hNHInputs.at(7));
            string ncc = GetStrFromHWND(hNHInputs.at(9));
            string hsd = GetStrFromHWND(hNHInputs.at(11));

            // 1. Validate: Format không rỗng
            if (sku.empty() || ten.empty() || slStr.empty() || giaStr.empty() || ncc.empty() || hsd.empty()) {
                MessageBoxW(hWnd, L"LỖI: Vui lòng nhập đầy đủ thông tin Nhập kho!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0; // Chặn lại, KHÔNG thêm vào List
            }

            // 2. Validate: Đúng kiểu số và giá trị > 0
            int sl = 0;
            double gia = 0.0;
            try {
                sl = stoi(slStr);
                gia = stod(giaStr);
                if (sl <= 0 || gia <= 0) {
                    MessageBoxW(hWnd, L"LỖI: Số lượng và Giá nhập phải lớn hơn 0!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                    return 0;
                }
            }
            catch (...) {
                MessageBoxW(hWnd, L"LỖI: Số lượng và Giá nhập phải là chữ số!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            double thanhTien = sl * gia;
            double khauTru = 0.0; // Nhập kho thường không có khấu trừ trực tiếp trên từng món

            // 3. Kiểm tra SKU đã tồn tại trong ListView chưa?
            int itemCount = ListView_GetItemCount(hListViewNH);
            bool isExist = false;

            for (int i = 0; i < itemCount; i++) {
                wchar_t itemSKU[256] = { 0 };
                ListView_GetItemText(hListViewNH, i, 1, itemSKU, 256);
                wstring wsSKU(itemSKU);
                string currentSKU(wsSKU.begin(), wsSKU.end());

                if (currentSKU == sku) {
                    // ĐÃ TỒN TẠI -> Cộng dồn Số lượng & Thành tiền
                    wchar_t itemSL[256] = { 0 };
                    ListView_GetItemText(hListViewNH, i, 3, itemSL, 256);
                    int oldSL = _wtoi(itemSL);
                    int newSL = oldSL + sl;
                    double newTong = newSL * gia;

                    // Cập nhật lại giao diện
                    wstring wsNewSL = to_wstring(newSL);
                    wstring wsNewTong = to_wstring(newTong);
                    ListView_SetItemText(hListViewNH, i, 3, (LPWSTR)wsNewSL.c_str());
                    ListView_SetItemText(hListViewNH, i, 7, (LPWSTR)wsNewTong.c_str());

                    isExist = true;
                    break;
                }
            }

            // 4. CHƯA TỒN TẠI -> Tạo dòng mới với STT tịnh tiến
            if (!isExist) {
                int newRow = itemCount;
                wstring wsSTT = to_wstring(newRow + 1);
                wstring wSku(sku.begin(), sku.end());
                wstring wTen(ten.begin(), ten.end());
                wstring wSl = to_wstring(sl);
                wstring wGia = to_wstring(gia);
                wstring wKt = to_wstring(khauTru);
                wstring wHsd(hsd.begin(), hsd.end());
                wstring wTong = to_wstring(thanhTien);

                LVITEMW lvi = { 0 };
                lvi.mask = LVIF_TEXT;
                lvi.iItem = newRow;
                lvi.iSubItem = 0;
                lvi.pszText = (LPWSTR)wsSTT.c_str();
                ListView_InsertItem(hListViewNH, &lvi);

                ListView_SetItemText(hListViewNH, newRow, 1, (LPWSTR)wSku.c_str());
                ListView_SetItemText(hListViewNH, newRow, 2, (LPWSTR)wTen.c_str());
                ListView_SetItemText(hListViewNH, newRow, 3, (LPWSTR)wSl.c_str());
                ListView_SetItemText(hListViewNH, newRow, 4, (LPWSTR)wGia.c_str());
                ListView_SetItemText(hListViewNH, newRow, 5, (LPWSTR)wKt.c_str());
                ListView_SetItemText(hListViewNH, newRow, 6, (LPWSTR)wHsd.c_str());
                ListView_SetItemText(hListViewNH, newRow, 7, (LPWSTR)wTong.c_str());
            }

            // Xóa rỗng các ô nhập để chuẩn bị quét mã tiếp theo (Giữ lại Nhà CC)
            SetWindowTextW(hNHInputs.at(1), L"");
            SetWindowTextW(hNHInputs.at(3), L"");
            SetWindowTextW(hNHInputs.at(5), L"");
            SetWindowTextW(hNHInputs.at(7), L"");
            SetWindowTextW(hNHInputs.at(11), L"");
        }

        // ==================SỰ KIỆN: LƯU NHẬP KHO & GHI NHẬT KÝ==============
        if (id == BTN_NH_LUU) {
            int itemCount = ListView_GetItemCount(hListViewNH);

            // Rule 1: ListView rỗng -> Cảnh báo, không cho lưu
            if (itemCount == 0) {
                MessageBoxW(hWnd, L"LỖI: Danh sách trống! Vui lòng nhập hàng trước khi lưu.", L"Lỗi", MB_OK | MB_ICONERROR);
                return 0;
            }

            string ncc = GetStrFromHWND(hNHInputs.at(9));

            // Tự động tạo Ngày Nhập bằng thời gian thực của máy tính
            time_t now = time(0);
            tm ltm;
            localtime_s(&ltm, &now);
            char dateBuffer[80]; // (Tự gõ ngoặc vuông nếu web nuốt ký tự)
            strftime(dateBuffer, sizeof(dateBuffer), "%Y-%m-%d", &ltm);
            string ngayNhap = string(dateBuffer);

            // Rule 2: Đẩy chi tiết phiếu nhập (NCC, Ngày) vào Controller trước [1]
            appCtrl.importObj.setImportDetails(ncc, ngayNhap);

            // Rule 3: Ép dữ liệu tạm từ ListView xuống biến 'list' trong RAM
            for (int i = 0; i < itemCount; i++) {
                // (Tự gõ ngoặc vuông và số 256 nếu web nuốt ký tự)
                wchar_t wSku[256] = { 0 }, wTen[256] = { 0 }, wSl[256] = { 0 }, wGia[256] = { 0 }, wKt[256] = { 0 }, wHsd[256] = { 0 }, wTong[256] = { 0 };

                ListView_GetItemText(hListViewNH, i, 1, wSku, 256);
                ListView_GetItemText(hListViewNH, i, 2, wTen, 256);
                ListView_GetItemText(hListViewNH, i, 3, wSl, 256);
                ListView_GetItemText(hListViewNH, i, 4, wGia, 256);
                ListView_GetItemText(hListViewNH, i, 5, wKt, 256);
                ListView_GetItemText(hListViewNH, i, 6, wHsd, 256);
                ListView_GetItemText(hListViewNH, i, 7, wTong, 256);

                // Chốt chuỗi an toàn (Chống lỗi Different Containers)
                wstring wsSku(wSku);
                wstring wsTen(wTen);
                wstring wsHsd(wHsd);

                Item itm;
                itm.sku = string(wsSku.begin(), wsSku.end());
                itm.ten = string(wsTen.begin(), wsTen.end());
                itm.sl = _wtoi(wSl);
                itm.gia = _wtof(wGia);
                itm.khauTru = _wtof(wKt);
                itm.hsd = string(wsHsd.begin(), wsHsd.end());
                itm.tong = _wtof(wTong);

                // Ném Item vào mảng 'list' của Transaction cha
                appCtrl.importObj.addTempItem(itm);
            }

            // Rule 4: Kích hoạt đa hình lưu file tự động thông qua class cha
            appCtrl.switchTab(BTN_NHAP_KHO); // [2, 3]
            if (appCtrl.processSaveTransaction()) { // Gọi logic Validate -> Ghi File -> Ghi Nhật Ký
                MessageBoxW(hWnd, L"Lưu phiếu nhập kho thành công! Đã ghi file nhapkho.csv và nhatky.csv", L"Thành công", MB_OK | MB_ICONINFORMATION);

                // Rule 5: Reset giao diện
                ListView_DeleteAllItems(hListViewNH);
                for (int i = 1; i <= 11; i += 2) SetWindowTextW(hNHInputs.at(i), L"");
            }
            else {
                MessageBoxW(hWnd, L"Lỗi hệ thống khi lưu file! Vui lòng thử lại.", L"Lỗi", MB_OK | MB_ICONERROR);
            }
        }

        // ======SỰ KIỆN: NHẬP & THÊM VÀO LISTVIEW XUẤT KHO ================
        if (id == 1029 && IsWindowVisible(hListViewXH)) { // Chỉ chạy khi ở tab Xuất Kho
            // Lấy dữ liệu từ các ô trắng (Theo quy luật số lẻ)
            string sku = GetStrFromHWND(hXHInputs.at(1));
            string slStr = GetStrFromHWND(hXHInputs.at(5));

            // 1. Validate: Format không rỗng
            if (sku.empty() || slStr.empty()) {
                MessageBoxW(hWnd, L"LỖI: Vui lòng nhập SKU và Số lượng!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0; // KHÔNG thêm vào List
            }

            // 2. Validate: SKU hợp lệ
            if (!appCtrl.db.isValidSKU(sku)) {
                MessageBoxW(hWnd, L"LỖI: SKU không tồn tại trong kho!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            // 3. Validate: Số lượng > 0
            int sl = 0;
            try {
                sl = stoi(slStr);
                if (sl <= 0) {
                    MessageBoxW(hWnd, L"LỖI: Số lượng xuất phải lớn hơn 0!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                    return 0;
                }
            }
            catch (...) {
                MessageBoxW(hWnd, L"LỖI: Số lượng phải là chữ số!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            Product p = appCtrl.db.getProductInfo(sku);

            // 4. Validate: Số lượng xuất <= Số lượng Tồn kho
            if (sl > p.tonKho) {
                wstring errMsg = L"LỖI: Số lượng xuất (" + to_wstring(sl) + L") vượt quá Tồn kho hiện tại (" + to_wstring(p.tonKho) + L")!";
                MessageBoxW(hWnd, errMsg.c_str(), L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            // Nếu hợp lệ -> Tự động điền Tên và Giá từ RAM lên giao diện cho đẹp
            SetWindowTextA(hXHInputs.at(3), p.ten.c_str());
            SetWindowTextA(hXHInputs.at(7), to_string(p.gia).c_str());

            double thanhTien = sl * p.gia;
            double khauTru = 0.0;

            // 5. Kiểm tra SKU đã tồn tại trong ListView chưa?
            int itemCount = ListView_GetItemCount(hListViewXH);
            bool isExist = false;

            for (int i = 0; i < itemCount; i++) {
                wchar_t itemSKU[256] = { 0 }; // (Tự gõ ngoặc vuông nếu web bị nuốt)
                ListView_GetItemText(hListViewXH, i, 1, itemSKU, 256);
                wstring wsSKU(itemSKU);
                string currentSKU(wsSKU.begin(), wsSKU.end());

                if (currentSKU == sku) {
                    // ĐÃ TỒN TẠI -> Cộng dồn
                    wchar_t itemSL[256] = { 0 };
                    ListView_GetItemText(hListViewXH, i, 3, itemSL, 256);
                    int oldSL = _wtoi(itemSL);
                    int newSL = oldSL + sl;

                    // Phải Validate lại tổng số lượng gộp xem có lố tồn kho không
                    if (newSL > p.tonKho) {
                        MessageBoxW(hWnd, L"LỖI: Tổng số lượng cộng dồn vượt quá Tồn kho!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                        return 0;
                    }

                    double newTong = newSL * p.gia;

                    // Cập nhật lại giao diện
                    wstring wsNewSL = to_wstring(newSL);
                    wstring wsNewTong = to_wstring(newTong);
                    ListView_SetItemText(hListViewXH, i, 3, (LPWSTR)wsNewSL.c_str());
                    ListView_SetItemText(hListViewXH, i, 7, (LPWSTR)wsNewTong.c_str());

                    isExist = true;
                    break;
                }
            }

            // 6. CHƯA TỒN TẠI -> Thêm dòng mới
            if (!isExist) {
                int newRow = itemCount;
                wstring wsSTT = to_wstring(newRow + 1);
                wstring wSku(sku.begin(), sku.end());
                wstring wTen(p.ten.begin(), p.ten.end());
                wstring wSl = to_wstring(sl);
                wstring wGia = to_wstring(p.gia);
                wstring wKt = to_wstring(khauTru);
                wstring wHsd(p.hsd.begin(), p.hsd.end());
                wstring wTong = to_wstring(thanhTien);

                LVITEMW lvi = { 0 };
                lvi.mask = LVIF_TEXT;
                lvi.iItem = newRow;
                lvi.iSubItem = 0;
                lvi.pszText = (LPWSTR)wsSTT.c_str();
                ListView_InsertItem(hListViewXH, &lvi);

                ListView_SetItemText(hListViewXH, newRow, 1, (LPWSTR)wSku.c_str());
                ListView_SetItemText(hListViewXH, newRow, 2, (LPWSTR)wTen.c_str());
                ListView_SetItemText(hListViewXH, newRow, 3, (LPWSTR)wSl.c_str());
                ListView_SetItemText(hListViewXH, newRow, 4, (LPWSTR)wGia.c_str());
                ListView_SetItemText(hListViewXH, newRow, 5, (LPWSTR)wKt.c_str());
                ListView_SetItemText(hListViewXH, newRow, 6, (LPWSTR)wHsd.c_str());
                ListView_SetItemText(hListViewXH, newRow, 7, (LPWSTR)wTong.c_str());
            }

            // Xóa rỗng các ô nhập để chuẩn bị quét mã tiếp theo
            SetWindowTextW(hXHInputs.at(1), L"");
            SetWindowTextW(hXHInputs.at(5), L"");
        }

        // ===============SỰ KIỆN: LƯU XUẤT KHO & GHI NHẬT KÝ================
        if (id == BTN_XH_LUU) {
            int itemCount = ListView_GetItemCount(hListViewXH);

            if (itemCount == 0) {
                MessageBoxW(hWnd, L"LỖI: Danh sách trống! Vui lòng nhập hàng trước khi xuất.", L"Lỗi", MB_OK | MB_ICONERROR);
                return 0;
            }
            string lyDo = GetStrFromHWND(hXHInputs.at(9));
            if (lyDo.empty() ||
                (lyDo != "Muon hang" && lyDo != "MUON HANG" &&
                    lyDo != "Tieu huy" && lyDo != "TIEU HUY" &&
                    lyDo != "Thien nguyen" && lyDo != "THIEN NGUYEN")) {
                MessageBoxW(hWnd, L"LỖI: Ly do phai nhap dung 1 trong 3 loai:\nMUON HANG\nTIEU HUY\nTHIEN NGUYEN", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            // Tự động tạo Ngày Xuất bằng thời gian thực
            time_t now = time(0);
            tm ltm;
            localtime_s(&ltm, &now);
            char dateBuffer[80];
            strftime(dateBuffer, sizeof(dateBuffer), "%Y-%m-%d", &ltm);
            string ngayXuat = string(dateBuffer);

            // Truyền Lý Do và Ngày Xuất xuống class Export
            appCtrl.exportObj.setExportDetails(lyDo, ngayXuat);

            // Ép dữ liệu tạm từ ListView xuống RAM
            for (int i = 0; i < itemCount; i++) {
                wchar_t wSku[256] = { 0 }, wTen[256] = { 0 }, wSl[256] = { 0 }, wGia[256] = { 0 }, wKt[256] = { 0 }, wHsd[256] = { 0 }, wTong[256] = { 0 };

                ListView_GetItemText(hListViewXH, i, 1, wSku, 256);
                ListView_GetItemText(hListViewXH, i, 2, wTen, 256);
                ListView_GetItemText(hListViewXH, i, 3, wSl, 256);
                ListView_GetItemText(hListViewXH, i, 4, wGia, 256);
                ListView_GetItemText(hListViewXH, i, 5, wKt, 256);
                ListView_GetItemText(hListViewXH, i, 6, wHsd, 256);
                ListView_GetItemText(hListViewXH, i, 7, wTong, 256);

                wstring wsSku(wSku);
                wstring wsTen(wTen);
                wstring wsHsd(wHsd);

                Item itm;
                itm.sku = string(wsSku.begin(), wsSku.end());
                itm.ten = string(wsTen.begin(), wsTen.end());
                itm.sl = _wtoi(wSl);
                itm.gia = _wtof(wGia);
                itm.khauTru = _wtof(wKt);
                itm.hsd = string(wsHsd.begin(), wsHsd.end());
                itm.tong = _wtof(wTong);

                appCtrl.exportObj.addTempItem(itm);
            }

            // Kích hoạt Đa hình để ghi file
            appCtrl.switchTab(BTN_XUAT_KHO);
            if (appCtrl.processSaveTransaction()) {
                MessageBoxW(hWnd, L"Lưu phiếu xuất kho thành công! Đã ghi file xuatkho.csv và nhatky.csv", L"Thành công", MB_OK | MB_ICONINFORMATION);

                ListView_DeleteAllItems(hListViewXH);
                for (int i = 1; i <= 11; i += 2) SetWindowTextW(hXHInputs.at(i), L"");
            }
            else {
                MessageBoxW(hWnd, L"Lỗi hệ thống khi lưu file! Vui lòng thử lại.", L"Lỗi", MB_OK | MB_ICONERROR);
            }
        }

        // =================SỰ KIỆN: LƯU SỔ GHI CHÚ========================
        if (id == BTN_GC_LUU) {
            // 1. Lấy dữ liệu từ các ô nhập liệu (Quy luật vị trí số lẻ)
            string caLam = GetStrFromHWND(hGCInputs.at(1));
            string nguoiLap = GetStrFromHWND(hGCInputs.at(3));
            string noiDung = GetStrFromHWND(hGCInputs.at(5));
            string phanLoai = GetStrFromHWND(hGCInputs.at(7));
            string thoiGian = GetStrFromHWND(hGCInputs.at(9));
            string maLK = GetStrFromHWND(hGCInputs.at(11));

            // 2. Validate: Nội dung, Ca làm, Người lập không được rỗng [1, 2]
            if (noiDung.empty() || caLam.empty() || nguoiLap.empty() || phanLoai.empty()) {
                MessageBoxW(hWnd, L"LỖI: Vui lòng nhập đầy đủ Ca làm, Người lập, Nội dung và Phân loại!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0; // KHÔNG lưu, KHÔNG hiển thị ListView [2, 3]
            }

            // 3. Validate: Người lập hợp lệ (Có tồn tại trong kho RAM) [1]
            if (!appCtrl.db.isValidUser(nguoiLap)) {
                MessageBoxW(hWnd, L"LỖI: Mã Người Lập (QL/NV) không tồn tại trong hệ thống!", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            // 4. Validate: Phân loại bắt buộc thuộc danh sách (Chấp nhận cả in hoa từ bàn phím POS)
            if (phanLoai != "Thu tuc" && phanLoai != "THU TUC" &&
                phanLoai != "Giay to" && phanLoai != "GIAY TO" &&
                phanLoai != "Y te" && phanLoai != "Y TE" &&
                phanLoai != "Chay no" && phanLoai != "CHAY NO" &&
                phanLoai != "Thue" && phanLoai != "THUE") {
                MessageBoxW(hWnd, L"LỖI: Phân loại phải là 1 trong 5 loại:\nTHU TUC, GIAY TO, Y TE, CHAY NO, THUE", L"Lỗi Validate", MB_OK | MB_ICONERROR);
                return 0;
            }

            // 5. Tự động khởi tạo Thời gian thực & Mã Ghi Chú (GC + Timestamp)
            time_t now = time(0);
            tm ltm;
            localtime_s(&ltm, &now);

            char tBuf[80]; // (Tự gõ ngoặc vuông nếu web nuốt ký tự)
            strftime(tBuf, sizeof(tBuf), "%Y-%m-%d %H:%M:%S", &ltm);
            string curTime = string(tBuf);

            char mBuf[80];
            strftime(mBuf, sizeof(mBuf), "GC%Y%m%d%H%M%S", &ltm);
            string maGC = string(mBuf);

            // Nếu ô Thời gian người dùng không gõ gì, lấy thời gian thực tự động cho an toàn
            if (thoiGian.empty()) thoiGian = curTime;

            // 6. GHI VÀO FILE SỔ GHI CHÚ CHI TIẾT (soghichu.csv) [2]
            ofstream fileSo("soghichu.csv", ios::app);
            if (fileSo.is_open()) {
                fileSo << curTime << ",GHI_CHU," << caLam << "," << nguoiLap << ","
                    << phanLoai << "," << maLK << "," << noiDung << "\n";
                fileSo.close();
            }
            else {
                MessageBoxW(hWnd, L"LỖI: Không thể mở file soghichu.csv để ghi!", L"Lỗi Hệ Thống", MB_OK | MB_ICONERROR);
                return 0;
            }

            // 7. GHI VÀO FILE NHẬT KÝ TỔNG (nhatky.csv) [2, 3]
            ofstream fileNk("nhatky.csv", ios::app);
            if (fileNk.is_open()) {
                fileNk << curTime << ",GHI_CHU," << maGC << "\n";
                fileNk.close();
            }

            // 8. CẬP NHẬT HIỂN THỊ LÊN LISTVIEW (Real-time) [3]
            int newRow = ListView_GetItemCount(hListViewGC);
            wstring wsSTT = to_wstring(newRow + 1);
            wstring wCa(caLam.begin(), caLam.end());
            wstring wNguoi(nguoiLap.begin(), nguoiLap.end());
            wstring wLoai(phanLoai.begin(), phanLoai.end());
            wstring wTime(curTime.begin(), curTime.end());
            wstring wND(noiDung.begin(), noiDung.end());
            wstring wMaLK(maLK.begin(), maLK.end());

            LVITEMW lvi = { 0 };
            lvi.mask = LVIF_TEXT;
            lvi.iItem = newRow;
            lvi.iSubItem = 0;
            lvi.pszText = (LPWSTR)wsSTT.c_str();
            ListView_InsertItem(hListViewGC, &lvi);

            // Map cột đúng theo format: | STT | Ca | Người lập | Phân loại | Time | Nội dung | Mã liên quan | [2]
            ListView_SetItemText(hListViewGC, newRow, 1, (LPWSTR)wCa.c_str());
            ListView_SetItemText(hListViewGC, newRow, 2, (LPWSTR)wNguoi.c_str());
            ListView_SetItemText(hListViewGC, newRow, 3, (LPWSTR)wLoai.c_str());
            ListView_SetItemText(hListViewGC, newRow, 4, (LPWSTR)wTime.c_str());
            ListView_SetItemText(hListViewGC, newRow, 5, (LPWSTR)wND.c_str());
            ListView_SetItemText(hListViewGC, newRow, 6, (LPWSTR)wMaLK.c_str());

            // 9. Reset trắng giao diện để chuẩn bị nhập ghi chú tiếp theo
            for (int i = 1; i <= 11; i += 2) {
                // Có thể bỏ qua không xóa Ca làm và Người lập để User đỡ phải gõ lại nhiều lần
                if (i != 1 && i != 3) SetWindowTextW(hGCInputs.at(i), L"");
            }
            MessageBoxW(hWnd, L"Đã lưu Ghi chú thành công và ghi vào sổ nhật ký!", L"Thành công", MB_OK | MB_ICONINFORMATION);
        }

        if (HIWORD(wp) == EN_SETFOCUS) hActiveEdit = (HWND)lp;
        if (id >= BTN_KEY_BASE && id < BTN_KEY_BASE + 42) {
            const wchar_t* v = layout[id - BTN_KEY_BASE];
            if (wcscmp(v, L"<-") == 0) SendMessage(hActiveEdit, WM_CHAR, 0x08, 0);
            else if (wcscmp(v, L"Enter") == 0) {}
            else SendMessage(hActiveEdit, EM_REPLACESEL, TRUE, (LPARAM)v);
        }
        else if (id == BTN_KEY_BASE + 99) SendMessage(hActiveEdit, EM_REPLACESEL, TRUE, (LPARAM)L" ");
        break;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        if (sysManager.getStatus()) {
            Graphics g(hdc);
            DrawLargeLogo(g, 600, 250, 50);
        }
        EndPaint(hWnd, &ps);
        break;
    }
    case WM_DESTROY: PostQuitMessage(0); break;
    default: return DefWindowProc(hWnd, msg, wp, lp);
    } return 0;
}

int WINAPI WinMain(HINSTANCE h, HINSTANCE hP, LPSTR lp, int n) {
    GdiplusStartupInput gsi;
    ULONG_PTR token;
    GdiplusStartup(&token, &gsi, NULL);

    WNDCLASS wc = { 0 };
    wc.lpfnWndProc = WndProc;
    wc.hInstance = h;
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"GO_POS";
    RegisterClass(&wc);

    CreateWindow(L"GO_POS", L"GO POS System Pro", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 100, 100, 1100, 800, NULL, NULL, h, NULL);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    GdiplusShutdown(token);
    return 0;
}
